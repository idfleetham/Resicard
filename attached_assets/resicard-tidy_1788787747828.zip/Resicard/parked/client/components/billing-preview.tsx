import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardDescription, CardBody } from "@/ui/Card";
import { MetricTile } from "@/ui/MetricTile";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAuth } from "@/hooks/use-auth";
import { Download, Calendar, CreditCard, TrendingUp, AlertCircle } from "lucide-react";
import { format, startOfMonth, endOfMonth, subMonths, addMonths } from "date-fns";

interface BillingPeriod {
  id: string;
  period: string;
  redemptions: number;
  totalFees: number;
  status: 'draft' | 'pending_dd' | 'collected';
  dueDate: string;
}

export default function BillingPreview() {
  const { user } = useAuth();
  const [selectedPeriod, setSelectedPeriod] = useState("current");
  
  const { data: billingStats } = useQuery({
    queryKey: ['/api/billing/stats'],
    enabled: !!user && user.role === 'merchant',
  });

  // Use real billing data or fallback to default
  const currentPeriod: BillingPeriod = {
    id: "current",
    period: billingStats?.period || format(new Date(), "MMMM yyyy"),
    redemptions: billingStats?.redemptions || 0,
    totalFees: billingStats?.totalFees || 0,
    status: billingStats?.status || "draft",
    dueDate: format(endOfMonth(new Date()), "yyyy-MM-dd"),
  };

  const feePerRedemption = billingStats?.averageFee || 0.50;

  const handleDownloadInvoice = (periodId: string) => {
    // Use current period data for download
    const period = currentPeriod;
    if (!period) return;

    // Create CSV content with detailed breakdown
    const csvData = [
      ["Item", "Quantity", "Rate", "Amount"],
    ];

    // Add detailed breakdown if available
    if (billingStats?.detailedBreakdown && billingStats.detailedBreakdown.length > 0) {
      billingStats.detailedBreakdown.forEach((item: any) => {
        csvData.push([
          item.description,
          item.quantity.toString(),
          `£${item.rate.toFixed(2)}`,
          `£${item.amount.toFixed(2)}`
        ]);
      });
    } else {
      // Fallback to summary line
      csvData.push([
        "Redemption Processing Fee",
        period.redemptions.toString(),
        `£${feePerRedemption.toFixed(2)}`,
        `£${(billingStats?.netFees || period.totalFees).toFixed(2)}`
      ]);
    }

    // Add VAT as a separate line item
    csvData.push([
      "VAT (20%)",
      "1",
      `£${(billingStats?.vatAmount || 0).toFixed(2)}`,
      `£${(billingStats?.vatAmount || 0).toFixed(2)}`
    ]);

    csvData.push(
      [""],
      ["Net Fees:", "", "", `£${(billingStats?.netFees || period.totalFees).toFixed(2)}`],
      ["VAT (20%):", "", "", `£${(billingStats?.vatAmount || 0).toFixed(2)}`],
      ["Total Due:", "", "", `£${period.totalFees.toFixed(2)}`]
    );

    const csvContent = "data:text/csv;charset=utf-8," + 
      csvData.map(row => row.join(",")).join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `invoice-${period.period.replace(" ", "-")}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "draft":
        return <Badge variant="secondary">Draft</Badge>;
      case "pending_dd":
        return <Badge variant="default">Pending Direct Debit</Badge>;
      case "collected":
        return <Badge variant="destructive">Paid</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "draft":
        return <AlertCircle className="h-4 w-4 text-yellow-500" />;
      case "pending_dd":
        return <CreditCard className="h-4 w-4 text-blue-500" />;
      case "collected":
        return <TrendingUp className="h-4 w-4 text-green-500" />;
      default:
        return <Calendar className="h-4 w-4 text-gray-500" />;
    }
  };

  return (
    <div className="space-y-6 bg-bg min-h-screen p-6">
      {/* Header */}
      <div className="mb-5 rounded-2xl bg-gradient-to-r from-brand1/25 via-brand2/20 to-transparent border border-white/40 shadow-xl shadow-white/20 p-5">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-fg">Billing Preview</h1>
            <p className="text-slate-300 text-lg">View monthly fees and download invoices</p>
          </div>
          <div className="flex items-center space-x-2">
            <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
              <SelectTrigger className="w-40 border-white/40 shadow-xl shadow-white/20 bg-surface text-fg">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-surface2 border-white/40 shadow-xl shadow-white/20">
                <SelectItem key={currentPeriod.id} value={currentPeriod.id} className="text-fg">
                  {currentPeriod.period}
                </SelectItem>
              </SelectContent>
            </Select>
            <Button 
              onClick={() => handleDownloadInvoice(selectedPeriod)}
              className="bg-gradient-to-r from-brand1 to-brand2 text-white shadow-elev-1"
            >
              <Download className="w-4 h-4 mr-2" />
              Download
            </Button>
          </div>
        </div>
      </div>

      {/* Current Period Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <MetricTile 
          label="Redemptions" 
          value={currentPeriod.redemptions.toString()} 
          icon={<TrendingUp className="h-4 w-4" />}
          subtitle={currentPeriod.period}
        />
        <MetricTile 
          label="Fee Per Redemption" 
          value={`£${feePerRedemption.toFixed(2)}`} 
          icon={<CreditCard className="h-4 w-4" />}
          subtitle="Average rate"
        />
        <MetricTile 
          label="Total Fees" 
          value={`£${currentPeriod.totalFees.toFixed(2)}`} 
          icon={<Calendar className="h-4 w-4" />}
          subtitle={currentPeriod.status === 'draft' ? 'Estimated' : 'Final'}
        />
        <MetricTile 
          label="Status" 
          value={getStatusBadge(currentPeriod.status)} 
          icon={getStatusIcon(currentPeriod.status)}
          subtitle={`Due: ${format(new Date(currentPeriod.dueDate), "MMM d, yyyy")}`}
        />
      </div>

      {/* Billing Details */}
      <Card variant="elevated" className="bg-card border border-white/40 shadow-xl shadow-white/20">
        <CardHeader>
          <CardTitle className="text-xl">Billing Breakdown - {currentPeriod.period}</CardTitle>
          <CardDescription className="text-lg">
            Detailed breakdown of fees for the selected billing period
          </CardDescription>
        </CardHeader>
        <CardBody>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="text-fg text-lg">Description</TableHead>
                <TableHead className="text-fg text-lg">Quantity</TableHead>
                <TableHead className="text-fg text-lg">Rate</TableHead>
                <TableHead className="text-right text-fg text-lg">Amount</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {(billingStats?.detailedBreakdown || []).map((item: any, index: number) => (
                <TableRow key={index}>
                  <TableCell className="text-slate-300 text-lg">{item.description}</TableCell>
                  <TableCell className="text-slate-300 text-lg">{item.quantity}</TableCell>
                  <TableCell className="text-slate-300 text-lg">£{item.rate.toFixed(2)}</TableCell>
                  <TableCell className="text-right text-slate-300 text-lg">£{item.amount.toFixed(2)}</TableCell>
                </TableRow>
              ))}
              {/* Fallback if no detailed breakdown */}
              {(!billingStats?.detailedBreakdown || billingStats.detailedBreakdown.length === 0) && (
                <TableRow>
                  <TableCell className="text-slate-300 text-lg">Redemption Processing Fee</TableCell>
                  <TableCell className="text-slate-300 text-lg">{currentPeriod.redemptions}</TableCell>
                  <TableCell className="text-slate-300 text-lg">£{feePerRedemption.toFixed(2)}</TableCell>
                  <TableCell className="text-right text-slate-300 text-lg">£{currentPeriod.totalFees.toFixed(2)}</TableCell>
                </TableRow>
              )}
              <TableRow>
                <TableCell className="text-slate-300 text-lg" colSpan={3}>Net Fees</TableCell>
                <TableCell className="text-right text-slate-300 text-lg">£{(billingStats?.netFees || currentPeriod.totalFees).toFixed(2)}</TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="text-slate-300 text-lg" colSpan={3}>VAT (20%)</TableCell>
                <TableCell className="text-right text-slate-300 text-lg">£{(billingStats?.vatAmount || 0).toFixed(2)}</TableCell>
              </TableRow>
              <TableRow className="border-t-2 border-white/40 shadow-xl shadow-white/20Strong font-medium">
                <TableCell className="text-fg font-semibold text-lg" colSpan={3}>Total Due</TableCell>
                <TableCell className="text-right text-fg font-semibold text-lg">£{currentPeriod.totalFees.toFixed(2)}</TableCell>
              </TableRow>
            </TableBody>
          </Table>

          {currentPeriod.status === 'draft' && (
            <div className="mt-4 p-4 bg-surface/50 border border-white/40 shadow-xl shadow-white/20 rounded-lg">
              <div className="flex items-start space-x-3">
                <AlertCircle className="h-5 w-5 text-yellow-500 mt-0.5" />
                <div>
                  <h4 className="text-lg font-medium text-fg">Draft Invoice</h4>
                  <p className="text-base text-slate-300 mt-1">
                    This is a draft invoice. The final amount will be calculated at the end of the billing period 
                    and collected via direct debit 15 days after month end.
                  </p>
                </div>
              </div>
            </div>
          )}
        </CardBody>
      </Card>

      {/* Payment Method */}
      <Card variant="elevated" className="bg-card border border-white/40 shadow-xl shadow-white/20">
        <CardHeader>
          <CardTitle className="text-xl">Payment Method</CardTitle>
          <CardDescription className="text-lg">How fees are collected</CardDescription>
        </CardHeader>
        <CardBody>
          <div className="flex items-center space-x-4">
            <div className="flex items-center justify-center w-12 h-12 bg-surface/50 rounded-full">
              <CreditCard className="h-6 w-6 text-fg" />
            </div>
            <div>
              <p className="font-medium text-fg text-lg">Direct Debit</p>
              <p className="text-lg text-slate-300">Fees are automatically collected monthly</p>
            </div>
          </div>
          
          <div className="mt-4 space-y-2">
            <div className="flex justify-between text-lg">
              <span className="text-slate-300">Collection Date:</span>
              <span className="text-fg">15 days following month end</span>
            </div>
            <div className="flex justify-between text-lg">
              <span className="text-slate-300">VAT:</span>
              <span className="text-fg">Added at 20%</span>
            </div>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}