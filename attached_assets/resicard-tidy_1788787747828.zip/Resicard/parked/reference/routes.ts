import type { Express } from "express";
import { createServer, type Server } from "http";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { storage } from "./storage";
import { insertUserSchema, insertEnhancedRedemptionSchema, insertOfferSchema } from "@shared/schema";
import { eq, sql, and, gt, desc, count } from "drizzle-orm";
import { db } from "./db";
import multer from "multer";
import express from "express";
import fs from "fs";
import { merchants, users, vouchers, redemptions, offers, loyaltyPrograms, loyaltyTiers, loyaltyRewards, loyaltyBalances, merchantTierPricing, userTierMemberships } from "@shared/schema";
import QRCode from "qrcode";
import { randomUUID } from "crypto";
import { PassKitService } from "./passkit";
import { ObjectStorageService } from "./objectStorage";

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";

// Initialize PassKit service
const passKitService = new PassKitService();

// Initialize Stripe (placeholder - will work when keys are provided)
let stripe: any = null;
if (process.env.STRIPE_SECRET_KEY) {
  const Stripe = require('stripe');
  stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
    apiVersion: "2023-10-16",
  });
}

// Extend the Request interface to include user
declare global {
  namespace Express {
    interface Request {
      user?: any;
    }
  }
}

// Middleware to verify JWT token
function authenticateToken(req: any, res: any, next: any) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    console.log('No token provided in request');
    return res.sendStatus(401);
  }

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) {
      console.log('JWT verification error:', err.message);
      return res.sendStatus(403);
    }
    req.user = user;
    next();
  });
}

// Middleware to check if user has required role
function requireRole(role: string) {
  return (req: any, res: any, next: any) => {
    if (req.user.role !== role) {
      return res.sendStatus(403);
    }
    next();
  };
}

// UK postcode validation - basic implementation for St Andrews area
function validatePostcode(postcode: string): boolean {
  const stAndrewsPostcodes = ['KY16', 'KY15', 'DD6', 'DD5'];
  const postcodePrefix = postcode.toUpperCase().substring(0, 4);
  return stAndrewsPostcodes.some(prefix => postcodePrefix.startsWith(prefix));
}

// Database connection is initialized in ./db.ts and imported

// Setup multer for file uploads
const upload = multer({ dest: "uploads/" });

// Helper function to get merchant ID from authenticated user
function getMerchantId(req: any): number {
  return parseInt(req.user.id);
}

// Loyalty points awarding function
async function awardLoyaltyPoints({
  merchantId,
  userId,
  basketValue,
  redemptionValue,
  type = 'purchase'
}: {
  merchantId: number;
  userId: number;
  basketValue: number;
  redemptionValue: number;
  type?: string;
}) {
  try {
    // For simplicity, use a default loyalty program with 1 point per £1
    const basePointsPerPound = 1;
    
    // Calculate points based on the actual spend amount (use redemption value as minimum)
    let earnAmount = Math.max(basketValue, redemptionValue); 
    
    // Find or create loyalty balance for this user and merchant
    let loyaltyBalance = await db.execute(sql`
      SELECT lb.*, lt.points_multiplier 
      FROM loyalty_balances lb
      LEFT JOIN loyalty_tiers lt ON lb.tier = lt.id::text
      WHERE lb.user_id = ${userId} AND lb.merchant_id = ${merchantId}
    `);
    
    // Get current tier multiplier (default to 1.0 for Bronze/new users)
    let tierMultiplier = 1.0;
    if (loyaltyBalance.rows.length > 0 && loyaltyBalance.rows[0].points_multiplier) {
      tierMultiplier = parseFloat(loyaltyBalance.rows[0].points_multiplier);
    }
    
    // Apply tier multiplier to points calculation
    const basePoints = Math.floor(earnAmount * basePointsPerPound);
    const pointsToAdd = Math.floor(basePoints * tierMultiplier);
    
    if (pointsToAdd <= 0) {
      return { pointsAdded: 0, stampsAdded: 0, message: 'No points to award' };
    }

    console.log(`Awarding ${pointsToAdd} points to user ${userId} for merchant ${merchantId} (transaction: £${earnAmount.toFixed(2)}, tier multiplier: ${tierMultiplier}x)`);
    
    if (loyaltyBalance.rows.length === 0) {
      // Create new loyalty balance
      await db.execute(sql`
        INSERT INTO loyalty_balances (user_id, merchant_id, balance, tier, created_at, updated_at)
        VALUES (${userId}, ${merchantId}, ${pointsToAdd}, null, NOW(), NOW())
      `);
    } else {
      // Update existing balance
      const currentPoints = parseFloat(loyaltyBalance.rows[0].balance) || 0;
      await db.execute(sql`
        UPDATE loyalty_balances 
        SET balance = ${currentPoints + pointsToAdd}, updated_at = NOW()
        WHERE user_id = ${userId} AND merchant_id = ${merchantId}
      `);
    }

    // Check for tier upgrades after awarding points
    const updatedBalance = await db.execute(sql`
      SELECT lb.balance, lt.id as current_tier_id, lt.threshold_points as current_threshold
      FROM loyalty_balances lb
      LEFT JOIN loyalty_tiers lt ON lb.tier = lt.id::text
      WHERE lb.user_id = ${userId} AND lb.merchant_id = ${merchantId}
    `);

    if (updatedBalance.rows.length > 0) {
      const balance = updatedBalance.rows[0];
      const newPoints = parseFloat(balance.balance) || 0;
      
      // Find highest tier this user qualifies for
      const availableTiers = await db.execute(sql`
        SELECT lt.* FROM loyalty_tiers lt
        JOIN loyalty_programs lp ON lt.program_id = lp.id
        WHERE lp.merchant_id = ${merchantId}
        AND lt.threshold_points <= ${newPoints}
        ORDER BY lt.threshold_points DESC
        LIMIT 1
      `);

      if (availableTiers.rows.length > 0) {
        const newTier = availableTiers.rows[0];
        if (!balance.current_tier_id || newTier.id !== balance.current_tier_id) {
          // User qualifies for a new tier!
          await db.execute(sql`
            UPDATE loyalty_balances 
            SET tier = ${newTier.id}::text, updated_at = NOW()
            WHERE user_id = ${userId} AND merchant_id = ${merchantId}
          `);
          console.log(`User ${userId} upgraded to tier ${newTier.name} for merchant ${merchantId}`);
        }
      }
    }

    return { 
      pointsAdded: pointsToAdd, 
      stampsAdded: 0, 
      message: `Awarded ${pointsToAdd} points for £${earnAmount.toFixed(2)} transaction` 
    };
  } catch (error) {
    console.error('Error in awardLoyaltyPoints:', error);
    return { pointsAdded: 0, stampsAdded: 0, message: 'Error awarding points' };
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Serve uploaded files statically
  app.use("/uploads", express.static("uploads"));

  // Serve public objects from cloud storage
  app.get("/public-objects/:filePath(*)", async (req, res) => {
    const filePath = req.params.filePath;
    const objectStorageService = new ObjectStorageService();
    try {
      const file = await objectStorageService.searchPublicObject(filePath);
      if (!file) {
        return res.status(404).json({ error: "File not found" });
      }
      objectStorageService.downloadObject(file, res);
    } catch (error) {
      console.error("Error searching for public object:", error);
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  // Simple placeholder image endpoint
  app.get("/api/placeholder/:width/:height", (req, res) => {
    const { width, height } = req.params;
    const svg = `<svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
      <rect width="${width}" height="${height}" fill="#374151"/>
      <text x="50%" y="50%" font-family="system-ui" font-size="14" fill="#9CA3AF" text-anchor="middle" alignment-baseline="middle">
        ${width}x${height}
      </text>
    </svg>`;
    
    res.setHeader('Content-Type', 'image/svg+xml');
    res.send(svg);
  });
  
  // Authentication routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists" });
      }

      // Validate postcode for residents
      if (userData.role === 'resident' && userData.postcode) {
        if (!validatePostcode(userData.postcode)) {
          return res.status(400).json({ 
            message: "Postcode is outside the St Andrews area (must be within 10 miles)" 
          });
        }
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(userData.password, 10);
      
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword,
      });

      // Generate JWT token
      const token = jwt.sign(
        { id: user.id, username: user.username, role: user.role },
        JWT_SECRET,
        { expiresIn: '7d' }
      );

      res.json({
        user: { ...user, password: undefined },
        token,
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Admin registration endpoint (protected)
  app.post("/api/auth/register-admin", async (req, res) => {
    try {
      const { username, email, password, adminSecret } = req.body;
      
      // Check admin secret (simple protection - in production use better security)
      if (adminSecret !== "localperks-admin-2024") {
        return res.status(403).json({ message: "Invalid admin secret" });
      }
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(password, 10);
      
      const user = await storage.createUser({
        username,
        email,
        password: hashedPassword,
        role: 'admin',
      });

      // Generate JWT token
      const token = jwt.sign(
        { id: user.id, username: user.username, role: user.role },
        JWT_SECRET,
        { expiresIn: '7d' }
      );

      res.json({
        user: { ...user, password: undefined },
        token,
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const validPassword = await bcrypt.compare(password, user.password);
      if (!validPassword) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Generate JWT token
      const token = jwt.sign(
        { id: user.id, username: user.username, role: user.role },
        JWT_SECRET,
        { expiresIn: '7d' }
      );

      res.json({
        user: { ...user, password: undefined },
        token,
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Rate limiting for password reset (basic in-memory implementation)
  const resetRequestCounts = new Map<string, { count: number; lastReset: number }>();
  const RESET_RATE_LIMIT = 3; // 3 requests per hour
  const RESET_RATE_WINDOW = 60 * 60 * 1000; // 1 hour in milliseconds

  function checkResetRateLimit(ip: string): boolean {
    const now = Date.now();
    const existing = resetRequestCounts.get(ip);
    
    if (!existing || now - existing.lastReset > RESET_RATE_WINDOW) {
      resetRequestCounts.set(ip, { count: 1, lastReset: now });
      return true;
    }
    
    if (existing.count >= RESET_RATE_LIMIT) {
      return false;
    }
    
    existing.count++;
    return true;
  }

  // Password reset request endpoint
  app.post("/api/auth/forgot-password", async (req, res) => {
    try {
      const { email } = req.body;
      
      // Validate email format
      if (!email || !email.includes('@')) {
        return res.status(400).json({ message: "Valid email address is required" });
      }

      // Check rate limit
      const clientIp = req.ip || req.connection.remoteAddress || 'unknown';
      if (!checkResetRateLimit(clientIp)) {
        return res.status(429).json({ 
          message: "Too many password reset requests. Please try again later." 
        });
      }

      // Create password reset request (always returns success to prevent account enumeration)
      await storage.createPasswordResetRequest(email.toLowerCase().trim(), {
        ip: clientIp,
        userAgent: req.headers['user-agent']
      });

      res.json({ 
        message: "If an account with that email exists, a password reset link has been sent." 
      });
    } catch (error: any) {
      console.error('Password reset request error:', error);
      res.status(500).json({ message: "An error occurred. Please try again later." });
    }
  });

  // Password reset confirmation endpoint
  app.post("/api/auth/reset-password", async (req, res) => {
    try {
      const { token, password } = req.body;
      
      // Validate input
      if (!token || !password) {
        return res.status(400).json({ message: "Token and new password are required" });
      }

      if (password.length < 6) {
        return res.status(400).json({ message: "Password must be at least 6 characters long" });
      }

      // Hash the new password
      const newPasswordHash = await bcrypt.hash(password, 12);

      // Consume the reset token and update password
      const result = await storage.consumePasswordResetToken(token, newPasswordHash);

      res.json({ 
        message: "Password reset successful. You can now log in with your new password.",
        userId: result.userId 
      });
    } catch (error: any) {
      console.error('Password reset error:', error);
      // Generic error message to prevent information leakage
      res.status(400).json({ message: "Invalid or expired reset token" });
    }
  });

  app.get("/api/auth/me", authenticateToken, async (req, res) => {
    try {
      const user = await storage.getUser(req.user.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json({ ...user, password: undefined });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Update user profile
  app.put("/api/profile", authenticateToken, async (req, res) => {
    try {
      const { username, email, profilePhoto } = req.body;
      
      const updatedUser = await storage.updateUserProfile(req.user.id, {
        username,
        email,
        profilePhoto,
      });
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({ ...updatedUser, password: undefined });
    } catch (error: any) {
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  // Update merchant business details
  app.put("/api/merchants/:id", authenticateToken, requireRole('merchant'), async (req, res) => {
    try {
      const merchantId = parseInt(req.params.id);
      
      // Verify the merchant is updating their own details
      if (merchantId !== req.user.id) {
        return res.status(403).json({ message: "Not authorized to update these details" });
      }

      const { name, email, phone, address, description } = req.body;
      
      const updatedUser = await storage.updateUserBusinessDetails(req.user.id, {
        businessName: name,
        businessPhone: phone,
        businessAddress: address,
        email: email,
      });
      
      if (!updatedUser) {
        return res.status(404).json({ message: "Merchant not found" });
      }
      
      res.json({ ...updatedUser, password: undefined });
    } catch (error: any) {
      console.error('Error updating merchant business details:', error);
      res.status(500).json({ message: "Failed to update business details" });
    }
  });

  // Update merchant profile settings
  app.put("/api/merchant", authenticateToken, requireRole('merchant'), async (req, res) => {
    try {
      const merchantId = getMerchantId(req);
      const payload = req.body;
      
      // Update user table business details
      const updatedUser = await storage.updateUserBusinessDetails(merchantId, {
        businessName: payload.name,
        businessPhone: payload.phone,
        businessAddress: payload.address,
        email: payload.email,
      });
      
      res.json({ ...updatedUser, password: undefined });
    } catch (error: any) {
      console.error('Error updating merchant profile:', error);
      res.status(500).json({ message: "Failed to update merchant profile" });
    }
  });

  // Upload merchant logo
  app.post("/api/merchant/upload/logo", authenticateToken, requireRole('merchant'), upload.single("file"), async (req, res) => {
    try {
      const merchantId = getMerchantId(req);
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }
      
      let logoUrl: string;
      
      try {
        // Try object storage first
        const objectStorageService = new ObjectStorageService();
        const fileName = `merchant-logos/${merchantId}-${Date.now()}-${req.file.originalname}`;
        
        logoUrl = await objectStorageService.uploadToPublicStorage(
          req.file.buffer || fs.readFileSync(req.file.path),
          fileName,
          req.file.mimetype
        );
      } catch (storageError) {
        // Fallback to base64 encoding if object storage fails
        console.log('Object storage failed, falling back to base64 encoding');
        const fileBuffer = req.file.buffer || fs.readFileSync(req.file.path);
        const base64Data = fileBuffer.toString('base64');
        logoUrl = `data:${req.file.mimetype};base64,${base64Data}`;
      }
      
      // Clean up temp file
      if (req.file.path) {
        fs.unlinkSync(req.file.path);
      }
      
      // Update user profile photo field to store logo URL or base64
      const updatedUser = await storage.updateUserProfile(merchantId, {
        profilePhoto: logoUrl
      });
      
      res.json({ ...updatedUser, password: undefined });
    } catch (error: any) {
      console.error('Error uploading merchant logo:', error);
      res.status(500).json({ message: "Failed to upload logo" });
    }
  });

  // Upload offer image
  app.post("/api/merchant/offers/:id/upload", authenticateToken, requireRole('merchant'), upload.single("file"), async (req, res) => {
    try {
      const dealId = parseInt(req.params.id);
      const merchantId = getMerchantId(req);
      
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }
      
      // Verify merchant owns this deal
      const deal = await storage.getDeal(dealId);
      if (!deal || deal.merchantId !== merchantId) {
        return res.status(403).json({ error: "Not authorized to update this offer" });
      }
      
      const imageUrl = `/uploads/${req.file.filename}`;
      
      // Update deal with new image URL
      const updatedDeal = await storage.updateDeal(dealId, {
        imageUrl: imageUrl
      });
      
      res.json(updatedDeal);
    } catch (error: any) {
      console.error('Error uploading offer image:', error);
      res.status(500).json({ message: "Failed to upload offer image" });
    }
  });

  // Offer routes
  app.get("/api/offers", async (req, res) => {
    try {
      // Get comprehensive offers directly
      const activeOffers = await db.select().from(offers).where(eq(offers.active, true));
      console.log(`Found ${activeOffers.length} active comprehensive offers`);
      
      const result = [];
      
      for (const offer of activeOffers) {
        // Get merchant info from merchants table
        const [merchant] = await db.select().from(merchants).where(eq(merchants.id, offer.merchantId));
        
        // Get user info to access profilePhoto (logo) - find user who created this merchant
        let merchantUser = null;
        // Since merchants table doesn't have createdBy, we need to find the user another way
        // For now, let's try to match by email if available
        if (merchant?.email) {
          const [user] = await db.select().from(users).where(eq(users.email, merchant.email));
          merchantUser = user;
        }
        
        const finalImageUrl = offer.imageUrl || merchantUser?.profilePhoto || merchant?.logoUrl || null;
        
        // Parse eligibleTiers from JSON string
        let eligibleTiers = [];
        if (offer.eligibleTiers) {
          try {
            eligibleTiers = typeof offer.eligibleTiers === 'string' ? JSON.parse(offer.eligibleTiers) : offer.eligibleTiers;
          } catch (e) {
            console.warn('Failed to parse eligibleTiers for offer:', offer.id);
          }
        }

        const convertedOffer = {
          id: offer.id,
          title: offer.title,
          description: offer.description || '',
          category: offer.category || 'General',
          discountType: offer.type === 'percentage_discount' ? 'percentage' : 'fixed',
          discountValue: offer.percentOff || 0,
          originalValue: null,
          usageLimit: offer.globalUsageLimit || offer.usageLimit || 999999,
          usageCount: offer.usageCount || 0,
          isActive: true,
          expiryDate: offer.validTo || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
          terms: offer.terms || offer.description || offer.title,
          imageUrl: finalImageUrl,
          createdAt: offer.createdAt,
          merchantId: offer.merchantId,
          merchantName: merchant?.name || 'Unknown Business',
          merchantAddress: merchant?.address || 'Address not provided',
          eligibleTiers: eligibleTiers
        };
        
        result.push(convertedOffer);
      }
      
      console.log(`Returning ${result.length} offers:`, result.map(r => r.title));
      res.json(result);
      
    } catch (error: any) {
      console.error('Error in /api/offers endpoint:', error);
      res.status(500).json({ message: error.message });
    }
  });

  // Create comprehensive offers
  app.post("/api/offers", authenticateToken, requireRole('merchant'), async (req, res) => {
    try {
      console.log('Received comprehensive offer data:', req.body);
      
      // Get or create merchant record for this user
      let merchant = await storage.getMerchantByUserId(req.user.id);
      if (!merchant) {
        // Create merchant record from user data
        merchant = await storage.createMerchantFromUser(req.user);
      }
      
      console.log('Found/created merchant:', merchant.id, 'for user:', req.user.id);
      
      // Process dates and numeric fields for comprehensive offers
      const processedData = {
        ...req.body,
        validFrom: req.body.validFrom ? new Date(req.body.validFrom) : new Date(),
        validTo: req.body.validTo ? new Date(req.body.validTo) : new Date(Date.now() + 365 * 24 * 60 * 60 * 1000), // Default 1 year from now
        daysOfWeek: req.body.daysOfWeek && req.body.daysOfWeek.length > 0 ? req.body.daysOfWeek : ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'], // Default all days
        timeSlots: req.body.timeSlots && Object.keys(req.body.timeSlots).length > 0 ? req.body.timeSlots : {}, // Default no time restrictions (all day)
        // Convert numeric fields from strings if needed
        fixedPrice: req.body.fixedPrice ? (typeof req.body.fixedPrice === 'string' ? parseFloat(req.body.fixedPrice) : req.body.fixedPrice) : undefined,
        originalValue: req.body.originalValue ? (typeof req.body.originalValue === 'string' ? parseFloat(req.body.originalValue) : req.body.originalValue) : undefined,
        merchantId: merchant.id, // Use the merchant UUID, not user ID
      };
      
      const offerData = insertOfferSchema.parse(processedData);
      console.log('Parsed comprehensive offer data:', offerData);
      
      // Ensure merchant ID is properly set after parsing
      const finalOfferData = {
        ...offerData,
        merchantId: merchant.id
      };
      console.log('Final offer data with merchant ID:', finalOfferData.merchantId);
      
      const offer = await storage.createOffer(finalOfferData);
      
      res.json(offer);
    } catch (error: any) {
      console.error('Comprehensive offer creation error:', error);
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/deals", authenticateToken, requireRole('merchant'), async (req, res) => {
    try {
      console.log('Received deal data:', req.body);
      
      // Convert expiryDate string to Date object before validation
      const processedData = {
        ...req.body,
        expiryDate: new Date(req.body.expiryDate),
      };
      
      const dealData = insertOfferSchema.parse(processedData);
      console.log('Parsed deal data:', dealData);
      
      const deal = await storage.createDeal({
        ...dealData,
        merchantId: req.user.id,
      });
      
      res.json(deal);
    } catch (error: any) {
      console.error('Deal creation validation error:', error);
      res.status(400).json({ message: error.message });
    }
  });

  app.put("/api/deals/:id", authenticateToken, requireRole('merchant'), async (req, res) => {
    try {
      const dealId = parseInt(req.params.id);
      
      // Check if deal exists and belongs to the merchant
      const existingDeal = await storage.getDeal(dealId);
      if (!existingDeal) {
        return res.status(404).json({ message: "Deal not found" });
      }
      
      if (existingDeal.merchantId !== req.user.id && req.user.role !== 'admin') {
        return res.status(403).json({ message: "Not authorized to update this deal" });
      }
      
      // Convert expiryDate string to Date object before validation
      const processedData = {
        ...req.body,
        expiryDate: new Date(req.body.expiryDate),
      };
      
      const dealData = insertOfferSchema.parse(processedData);
      
      const updatedDeal = await storage.updateDeal(dealId, dealData);
      
      if (!updatedDeal) {
        return res.status(404).json({ message: "Deal not found" });
      }
      
      res.json(updatedDeal);
    } catch (error: any) {
      console.error('Deal update validation error:', error);
      res.status(400).json({ message: error.message });
    }
  });

  // Admin-only route to clean up demo data
  app.delete("/api/admin/cleanup-demo", authenticateToken, requireRole('admin'), async (req, res) => {
    try {
      // Delete specific demo deals and merchants
      const dealsToDelete = [1, 2, 3, 4]; // The Dunvegan, Maisha, Tailend, St Andrews Links
      const merchantsToDelete = [2, 4, 5, 6];
      
      for (const dealId of dealsToDelete) {
        await storage.deleteDeal(dealId);
      }
      
      res.json({ message: "Demo data cleaned up successfully" });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // QR Code voucher redemption endpoint
  app.post("/api/vouchers/redeem-qr", authenticateToken, requireRole('merchant'), async (req, res) => {
    try {
      const { voucherNumber, dealId, userId, merchantName, dealTitle } = req.body;
      
      if (!voucherNumber || !dealId || !userId) {
        return res.status(400).json({ message: "Missing required voucher data" });
      }
      
      // Find the voucher
      const voucher = await storage.getVoucherByNumber(voucherNumber);
      if (!voucher) {
        return res.status(404).json({ message: "Voucher not found" });
      }
      
      if (voucher.isUsed) {
        return res.status(400).json({ message: "Voucher has already been used" });
      }
      
      // Verify the voucher belongs to the deal
      if (voucher.dealId !== dealId) {
        return res.status(400).json({ message: "Voucher does not match the deal" });
      }
      
      // Check if voucher is expired
      if (new Date(voucher.expiresAt) < new Date()) {
        return res.status(400).json({ message: "Voucher has expired" });
      }
      
      // Get deal and verify merchant ownership
      const deal = await storage.getDeal(dealId);
      if (!deal) {
        return res.status(404).json({ message: "Deal not found" });
      }
      
      if (deal.merchantId !== req.user.id) {
        return res.status(403).json({ 
          message: `This voucher is for ${merchantName || 'another business'}. You can only redeem vouchers for your own deals.` 
        });
      }
      
      // Get user info for the redemption
      const customer = await storage.getUser(userId);
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      
      // Mark voucher as used
      const usedVoucher = await storage.useVoucher(voucherNumber);
      
      // Create redemption record
      await storage.createRedemption({
        offerId: `deal_${dealId}`, // Convert deal ID to offer ID format
        userId: userId,
        discountValue: null,
      });
      
      res.json({
        message: "Voucher redeemed successfully",
        voucherNumber,
        dealTitle,
        customerName: customer.username,
        redeemedAt: new Date(),
      });
    } catch (error: any) {
      console.error('QR redemption error:', error);
      res.status(500).json({ message: error.message || "Failed to redeem voucher" });
    }
  });

  // Public voucher verification endpoint (no auth required)
  app.get("/api/vouchers/verify", async (req, res) => {
    try {
      const { v: voucherNumber, d: dealId, u: userId } = req.query;
      
      if (!voucherNumber || !dealId || !userId) {
        return res.status(400).json({ message: "Missing required voucher parameters" });
      }
      
      // Find the voucher
      const voucher = await storage.getVoucherByNumber(voucherNumber as string);
      if (!voucher) {
        return res.status(404).json({ message: "Voucher not found" });
      }
      
      // Get deal information
      const deal = await storage.getDeal(dealId as string);
      if (!deal) {
        return res.status(404).json({ message: "Deal not found" });
      }
      
      // Get customer information
      const customer = await storage.getUser(parseInt(userId as string));
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      
      // Get merchant information
      const merchant = await storage.getUser(deal.merchantId);
      if (!merchant) {
        return res.status(404).json({ message: "Merchant not found" });
      }
      
      // Return voucher details for verification
      res.json({
        voucherNumber: voucher.voucherNumber,
        dealId: voucher.dealId,
        userId: customer.id,
        dealTitle: deal.title,
        merchantName: merchant.businessName || merchant.username,
        discountType: deal.discountType,
        discountValue: deal.discountValue,
        isUsed: voucher.isUsed,
        usedAt: voucher.usedAt,
        expiresAt: voucher.expiresAt,
        customerName: customer.username,
        customerPhoto: customer.profilePhoto
      });
    } catch (error: any) {
      console.error('Voucher verification error:', error);
      res.status(500).json({ message: error.message || "Failed to verify voucher" });
    }
  });

  app.get("/api/deals/merchant/:merchantId", authenticateToken, async (req, res) => {
    try {
      const merchantId = parseInt(req.params.merchantId);
      
      // Only allow merchants to view their own deals or admins to view any
      if (req.user.role !== 'admin' && req.user.id !== merchantId) {
        return res.sendStatus(403);
      }
      
      const deals = await storage.getDealsByMerchant(merchantId);
      res.json(deals);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.put("/api/deals/:id", authenticateToken, requireRole('merchant'), async (req, res) => {
    try {
      const dealId = parseInt(req.params.id);
      const updates = req.body;
      
      // Verify merchant owns this deal
      const deal = await storage.getDeal(dealId);
      if (!deal || deal.merchantId !== req.user.id) {
        return res.sendStatus(403);
      }
      
      const updatedDeal = await storage.updateDeal(dealId, updates);
      res.json(updatedDeal);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.delete("/api/deals/:id", authenticateToken, requireRole('merchant'), async (req, res) => {
    try {
      const dealId = parseInt(req.params.id);
      
      // Verify merchant owns this deal
      const deal = await storage.getDeal(dealId);
      if (!deal || deal.merchantId !== req.user.id) {
        return res.sendStatus(403);
      }
      
      const deleted = await storage.deleteDeal(dealId);
      res.json({ success: deleted });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Update merchant reservation settings
  app.put("/api/merchant/reservation", authenticateToken, async (req, res) => {
    try {
      if (req.user?.role !== "merchant") {
        return res.status(403).json({ error: "Access denied" });
      }

      // Mock implementation - in a real app, this would save to merchant record
      const { provider, url } = req.body;
      
      // Validate URL if provider is not 'none'
      if (provider !== 'none' && url) {
        try {
          new URL(url);
        } catch {
          return res.status(400).json({ error: "Invalid URL format" });
        }
      }

      // Mock response - in real implementation, update the merchant record
      res.json({ 
        success: true, 
        reservationProvider: provider,
        reservationUrl: url || null
      });
    } catch (error: any) {
      console.error("Error updating reservation settings:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Voucher creation routes (replaces immediate redemptions)
  app.post("/api/redemptions", authenticateToken, requireRole('resident'), async (req, res) => {
    try {
      const { dealId } = req.body;
      const userId = req.user.id;
      
      // Check if dealId is a UUID (comprehensive offer) or integer (simple deal)
      const isUUID = typeof dealId === 'string' && dealId.includes('-');
      let deal, activeVouchersCount;
      
      if (isUUID) {
        // Handle comprehensive offers
        const [offer] = await db.select().from(offers).where(eq(offers.id, dealId));
        if (!offer) {
          return res.status(404).json({ message: "Offer not found" });
        }
        
        if (!offer.active || (offer.validTo && new Date(offer.validTo) < new Date())) {
          return res.status(400).json({ message: "Offer is no longer active" });
        }

        // Check tier eligibility if offer has tier restrictions
        if (offer.eligibleTiers) {
          try {
            const requiredTiers = JSON.parse(offer.eligibleTiers);
            if (requiredTiers && requiredTiers.length > 0) {
              // Get user's current tiers from all merchants
              const userTiers = await db.execute(sql`
                SELECT DISTINCT lt.id, lt.name 
                FROM loyalty_balances lb
                JOIN loyalty_tiers lt ON lb.tier = lt.id::text
                WHERE lb.user_id = ${userId} AND lb.balance >= lt.threshold_points
              `);
              
              const userTierNames = userTiers.rows.map((tier: any) => tier.name);
              const hasRequiredTier = requiredTiers.some((reqTier: string) => userTierNames.includes(reqTier));
              
              if (!hasRequiredTier) {
                return res.status(403).json({ 
                  message: "You don't have the required loyalty tier for this offer",
                  requiredTiers,
                  userTiers: userTierNames
                });
              }
            }
          } catch (e) {
            console.warn("Error parsing eligibleTiers JSON:", e);
            // Continue without tier check if JSON is invalid
          }
        }
        
        // For comprehensive offers, we'll create vouchers differently
        // Convert offer to deal-like format for voucher creation
        const expiryDate = offer.validTo 
          ? new Date(offer.validTo)
          : new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
          
        deal = {
          id: dealId,
          title: offer.title,
          expiryDate: expiryDate,
          usageLimit: offer.maxPerTransaction || 100,
          isActive: offer.active ?? true
        };
        
        // Count existing vouchers for this offer (use a different storage method or mock for now)
        activeVouchersCount = 0; // For now, allow unlimited comprehensive offer redemptions
      } else {
        // Handle simple deals (integer IDs)  
        const dealIdNum = parseInt(dealId);
        deal = await storage.getDeal(dealIdNum.toString());
        if (!deal) {
          return res.status(404).json({ message: "Deal not found" });
        }
        
        if (!deal.active || (deal.validTo && new Date(deal.validTo) < new Date())) {
          return res.status(400).json({ message: "Deal is no longer active" });
        }
        
        activeVouchersCount = await storage.getActiveVouchersCount(dealIdNum);
        if (activeVouchersCount >= (deal.globalUsageLimit || 100)) {
          return res.status(400).json({ message: "Deal voucher limit reached" });
        }
      }
      
      // Generate unique voucher number
      const voucherNumber = `${dealId}-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`.toUpperCase();
      
      // Create voucher that expires with the deal
      // For UUID deals (comprehensive offers), we need to store the UUID in the voucherNumber for tracking
      // but use a placeholder dealId for the database
      const voucher = await storage.createVoucher({
        dealId: isUUID ? -1 : parseInt(dealId), // Use -1 as placeholder for UUID offers
        userId,
        voucherNumber,
        expiresAt: new Date(deal.validTo || deal.expiryDate || Date.now() + 30 * 24 * 60 * 60 * 1000),
      });

      // Store the original dealId (UUID or integer) in the voucher response for frontend use
      const voucherWithOriginalId = {
        ...voucher,
        originalDealId: dealId // Keep the original dealId for frontend compatibility
      };
      
      res.json({ 
        voucher: voucherWithOriginalId, 
        voucherPosition: `${activeVouchersCount + 1} of ${deal.globalUsageLimit || deal.usageLimit || 100}`,
        message: "Voucher created successfully" 
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Voucher wallet routes
  app.get("/api/vouchers/user/:userId", authenticateToken, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      
      // Only allow users to view their own vouchers or admins to view any
      if (req.user.role !== 'admin' && req.user.id !== userId) {
        return res.sendStatus(403);
      }
      
      const vouchers = await storage.getVouchersByUser(userId);
      res.json(vouchers);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/vouchers/use", authenticateToken, async (req, res) => {
    try {
      const { voucherNumber } = req.body;
      
      const voucher = await storage.getVoucherByNumber(voucherNumber);
      if (!voucher) {
        return res.status(404).json({ message: "Voucher not found" });
      }
      
      if (voucher.isUsed) {
        return res.status(400).json({ message: "Voucher already used" });
      }
      
      if (new Date() > new Date(voucher.expiresAt)) {
        return res.status(400).json({ message: "Voucher has expired" });
      }
      
      const usedVoucher = await storage.useVoucher(voucherNumber);
      res.json({ voucher: usedVoucher, message: "Voucher redeemed successfully" });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Refresh expired voucher endpoint
  app.post("/api/vouchers/refresh", authenticateToken, requireRole('resident'), async (req, res) => {
    try {
      const { voucherId } = req.body;
      const userId = req.user.id;
      
      // Get the existing voucher
      const existingVoucher = await storage.getVoucherById(voucherId);
      if (!existingVoucher) {
        return res.status(404).json({ message: "Voucher not found" });
      }
      
      // Verify the voucher belongs to the user
      if (existingVoucher.userId !== userId) {
        return res.status(403).json({ message: "Not authorized to refresh this voucher" });
      }
      
      // Only allow refreshing expired, unused vouchers
      if (existingVoucher.isUsed) {
        return res.status(400).json({ message: "Cannot refresh used voucher" });
      }
      
      if (new Date(existingVoucher.expiresAt) >= new Date()) {
        return res.status(400).json({ message: "Voucher is not expired" });
      }
      
      // Get the original deal/offer to check availability
      const originalDealId = existingVoucher.dealId;
      const isUUID = existingVoucher.voucherNumber.includes('-') && originalDealId === -1;
      let deal;
      
      if (isUUID) {
        // Extract UUID from voucher number for comprehensive offers
        // Voucher number format: UUID-timestamp-random, so extract first 5 parts to get UUID
        const voucherParts = existingVoucher.voucherNumber.split('-');
        const dealId = voucherParts.slice(0, 5).join('-');
        const [offer] = await db.select().from(offers).where(eq(offers.id, dealId));
        if (!offer) {
          return res.status(404).json({ message: "Original offer not found" });
        }
        
        if (!offer.active || (offer.validTo && new Date(offer.validTo) < new Date())) {
          return res.status(400).json({ message: "Original offer is no longer available" });
        }
        
        deal = {
          id: dealId,
          title: offer.title,
          expiryDate: offer.validTo || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
        };
      } else {
        // Handle simple deals
        deal = await storage.getDeal(originalDealId);
        if (!deal) {
          return res.status(404).json({ message: "Original deal not found" });
        }
        
        if (!deal.isActive || new Date(deal.expiryDate) < new Date()) {
          return res.status(400).json({ message: "Original deal is no longer available" });
        }
        
        // Check usage limits for simple deals
        const activeVouchersCount = await storage.getActiveVouchersCount(originalDealId);
        if (activeVouchersCount >= deal.usageLimit) {
          return res.status(400).json({ message: "Deal voucher limit reached" });
        }
      }
      
      // Delete the old expired voucher
      await storage.deleteVoucher(voucherId, userId);
      
      // Generate new voucher number
      const voucherNumber = `${deal.id}-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`.toUpperCase();
      
      // Create new voucher with fresh expiration
      const newVoucher = await storage.createVoucher({
        dealId: isUUID ? -1 : originalDealId,
        userId,
        voucherNumber,
        expiresAt: new Date(deal.validTo || deal.expiryDate || Date.now() + 30 * 24 * 60 * 60 * 1000),
      });
      
      res.json({ 
        voucher: newVoucher, 
        message: "Voucher refreshed successfully" 
      });
    } catch (error: any) {
      console.error('Voucher refresh error:', error);
      res.status(400).json({ message: error.message });
    }
  });

  app.delete("/api/vouchers/:id", authenticateToken, async (req, res) => {
    try {
      const voucherId = parseInt(req.params.id);
      const userId = req.user.id;
      
      if (isNaN(voucherId)) {
        return res.status(400).json({ message: "Invalid voucher ID" });
      }
      
      const deleted = await storage.deleteVoucher(voucherId, userId);
      
      if (!deleted) {
        return res.status(404).json({ message: "Voucher not found or not authorized" });
      }
      
      res.json({ message: "Voucher deleted successfully" });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/redemptions/user/:userId", authenticateToken, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      
      // Only allow users to view their own redemptions or admins to view any
      if (req.user.role !== 'admin' && req.user.id !== userId) {
        return res.sendStatus(403);
      }
      
      const redemptions = await storage.getRedemptionsByUser(userId);
      res.json(redemptions);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Removed duplicate endpoint - using minimal version below

  // Subscription management routes
  app.get("/api/subscription/plans", async (req, res) => {
    try {
      const plans = {
        individual: {
          monthly: { price: 9.99, priceId: "price_individual_monthly" },
          annual: { price: 99, priceId: "price_individual_annual" }
        },
        family: {
          monthly: { price: 19.99, priceId: "price_family_monthly" },
          annual: { price: 199, priceId: "price_family_annual" }
        }
      };
      res.json(plans);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/subscription/create", authenticateToken, requireRole('resident'), async (req, res) => {
    try {
      const { subscriptionType, subscriptionPlan, familyMembers } = req.body;
      const userId = req.user.id;
      
      // Get user details to check verification status
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Check if user has profile photo
      if (!user.profilePhoto) {
        return res.status(400).json({ 
          message: "Profile photo required. Please add a profile photo to your account before purchasing a subscription.",
          code: "PROFILE_PHOTO_REQUIRED"
        });
      }
      
      // Check if user's residency is verified
      if (!user.isResidencyVerified) {
        return res.status(400).json({ 
          message: "Account verification required. Please wait for your residency documents to be verified before purchasing a subscription.",
          code: "VERIFICATION_REQUIRED"
        });
      }
      
      // For family subscriptions, validate family members
      if (subscriptionType === 'family') {
        if (!familyMembers || !Array.isArray(familyMembers) || familyMembers.length === 0) {
          return res.status(400).json({ 
            message: "Family members required. Please add at least one family member for a family subscription.",
            code: "FAMILY_MEMBERS_REQUIRED"
          });
        }
        
        // Validate each family member
        for (const member of familyMembers) {
          if (!member.firstName || !member.surname || !member.age || !member.relationship) {
            return res.status(400).json({ 
              message: "All family member details are required (name, age, relationship).",
              code: "INVALID_FAMILY_MEMBER"
            });
          }
          
          if (member.age > 17 && member.relationship === 'child') {
            return res.status(400).json({ 
              message: "Children must be 17 years old or under.",
              code: "INVALID_CHILD_AGE"
            });
          }
        }
      }
      
      // Calculate membership expiry
      const now = new Date();
      const membershipExpiry = new Date(now);
      if (subscriptionPlan === 'monthly') {
        membershipExpiry.setMonth(membershipExpiry.getMonth() + 1);
      } else {
        membershipExpiry.setFullYear(membershipExpiry.getFullYear() + 1);
      }
      
      // Save family members if this is a family subscription
      if (subscriptionType === 'family' && familyMembers && familyMembers.length > 0) {
        await storage.createFamilyMembers(userId, familyMembers);
      }
      
      const updatedUser = await storage.updateUserSubscription(userId, {
        subscriptionType,
        subscriptionPlan,
        subscriptionStatus: 'active',
        membershipExpiry,
      });
      
      res.json({ user: updatedUser, message: "Subscription created successfully" });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/subscription/status", authenticateToken, requireRole('resident'), async (req, res) => {
    try {
      const user = await storage.getUser(req.user.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const subscription = {
        type: user.subscriptionType,
        plan: user.subscriptionPlan,
        status: user.subscriptionStatus,
        expiresAt: user.membershipExpiry,
        isActive: user.subscriptionStatus === 'active' && (!user.membershipExpiry || new Date() < new Date(user.membershipExpiry))
      };
      
      res.json(subscription);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Subscription change endpoint
  app.post("/api/subscription/change", authenticateToken, requireRole('resident'), async (req, res) => {
    try {
      const { subscriptionType, subscriptionPlan } = req.body;
      const userId = req.user.id;
      
      if (!subscriptionType || !subscriptionPlan) {
        return res.status(400).json({ message: "Subscription type and plan are required" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Calculate new membership expiry
      const now = new Date();
      const membershipExpiry = new Date(now);
      if (subscriptionPlan === 'monthly') {
        membershipExpiry.setMonth(membershipExpiry.getMonth() + 1);
      } else {
        membershipExpiry.setFullYear(membershipExpiry.getFullYear() + 1);
      }

      // Stripe integration placeholder
      let stripeSubscriptionId = user.stripeSubscriptionId;
      let stripeCustomerId = user.stripeCustomerId;
      
      if (stripe) {
        try {
          // Create or update Stripe customer
          if (!stripeCustomerId && user.email) {
            const customer = await stripe.customers.create({
              email: user.email,
              name: user.username,
            });
            stripeCustomerId = customer.id;
          }

          // Handle subscription change in Stripe
          if (stripeSubscriptionId) {
            // Update existing subscription
            await stripe.subscriptions.update(stripeSubscriptionId, {
              items: [{
                price: process.env[`STRIPE_PRICE_${subscriptionType.toUpperCase()}_${subscriptionPlan.toUpperCase()}`],
              }],
              proration_behavior: 'create_prorations',
            });
          } else {
            // Create new subscription
            const subscription = await stripe.subscriptions.create({
              customer: stripeCustomerId,
              items: [{
                price: process.env[`STRIPE_PRICE_${subscriptionType.toUpperCase()}_${subscriptionPlan.toUpperCase()}`],
              }],
            });
            stripeSubscriptionId = subscription.id;
          }
        } catch (stripeError: any) {
          console.warn('Stripe operation failed:', stripeError.message);
          // Continue without Stripe for now
        }
      }
      
      // Update user subscription
      const updatedUser = await storage.updateUserSubscription(userId, {
        subscriptionType,
        subscriptionPlan,
        subscriptionStatus: 'active',
        membershipExpiry,
        stripeCustomerId: stripeCustomerId || undefined,
        stripeSubscriptionId: stripeSubscriptionId || undefined,
      });
      
      res.json({ 
        user: updatedUser, 
        message: `Subscription changed to ${subscriptionType} ${subscriptionPlan} plan` 
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Subscription cancellation endpoint
  app.post("/api/subscription/cancel", authenticateToken, requireRole('resident'), async (req, res) => {
    try {
      const userId = req.user.id;
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Cancel in Stripe if configured
      if (stripe && user.stripeSubscriptionId) {
        try {
          await stripe.subscriptions.update(user.stripeSubscriptionId, {
            cancel_at_period_end: true
          });
        } catch (stripeError: any) {
          console.warn('Stripe cancellation failed:', stripeError.message);
          // Continue with local cancellation
        }
      }
      
      // Update user subscription status
      const updatedUser = await storage.updateUserSubscription(userId, {
        subscriptionType: user.subscriptionType || 'individual',
        subscriptionPlan: user.subscriptionPlan || 'monthly',
        subscriptionStatus: 'cancelled',
        membershipExpiry: user.membershipExpiry || new Date(),
        stripeCustomerId: user.stripeCustomerId || undefined,
        stripeSubscriptionId: user.stripeSubscriptionId || undefined,
      });
      
      res.json({ 
        user: updatedUser, 
        message: "Subscription cancelled. Access will continue until your current billing period ends." 
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Admin routes
  app.get("/api/admin/pending-businesses", authenticateToken, requireRole('admin'), async (req, res) => {
    try {
      const businesses = await storage.getPendingBusinesses();
      res.json(businesses);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/admin/verify-business/:id", authenticateToken, requireRole('admin'), async (req, res) => {
    try {
      const businessId = parseInt(req.params.id);
      const verifiedBusiness = await storage.verifyBusiness(businessId);
      res.json(verifiedBusiness);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/admin/stats", authenticateToken, requireRole('admin'), async (req, res) => {
    try {
      const stats = await storage.getPlatformStats();
      res.json(stats);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/admin/users", authenticateToken, requireRole('admin'), async (req, res) => {
    try {
      const { role } = req.query;
      let users;
      
      if (role) {
        users = await storage.getUsersByRole(role as string);
      } else {
        const residents = await storage.getUsersByRole('resident');
        const merchants = await storage.getUsersByRole('merchant');
        users = [...residents, ...merchants];
      }
      
      // Remove passwords from response
      const safeUsers = users.map(user => ({ ...user, password: undefined }));
      res.json(safeUsers);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/admin/pending-businesses", authenticateToken, requireRole('admin'), async (req, res) => {
    try {
      const pendingBusinesses = await storage.getPendingBusinesses();
      const safeBusinesses = pendingBusinesses.map(user => ({ ...user, password: undefined }));
      res.json(safeBusinesses);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Document verification routes
  app.post("/api/documents/submit", authenticateToken, async (req, res) => {
    try {
      const { documentType, documentFile } = req.body;
      const userId = req.user.id;
      
      console.log(`Document submission for user ${userId}:`, {
        documentType,
        documentFileLength: documentFile?.length || 0,
        hasDocumentFile: !!documentFile
      });
      
      if (!documentType) {
        return res.status(400).json({ message: "Document type is required" });
      }
      
      if (!documentFile) {
        return res.status(400).json({ message: "Document file is required" });
      }
      
      // Check file size limit (400KB base64 = ~300KB actual)
      if (documentFile.length > 400000) {
        return res.status(400).json({ message: "Document file is too large. Please compress or resize your document." });
      }
      
      const updatedUser = await storage.submitDocument(userId, {
        documentType,
        documentFile,
      });
      
      if (!updatedUser) {
        return res.status(500).json({ message: "Failed to save document. Please try again." });
      }
      
      console.log(`Document submitted successfully for user ${userId}:`, {
        documentType: updatedUser?.documentType,
        documentStatus: updatedUser?.documentStatus,
        hasDocumentFile: !!updatedUser?.documentFile
      });
      
      res.json({ user: updatedUser, message: "Document submitted for verification" });
    } catch (error: any) {
      console.error(`Error submitting document for user ${req.user?.id}:`, error);
      
      // Provide more specific error messages
      if (error.message?.includes('connection')) {
        res.status(500).json({ message: "Database connection error. Please try again in a moment." });
      } else if (error.message?.includes('timeout')) {
        res.status(500).json({ message: "Request timed out. Please try with a smaller file." });
      } else {
        res.status(400).json({ message: error.message || "Failed to submit document" });
      }
    }
  });

  app.get("/api/admin/pending-documents", authenticateToken, requireRole('admin'), async (req, res) => {
    try {
      const pendingDocuments = await storage.getPendingDocuments();
      
      console.log(`Retrieved ${pendingDocuments.length} pending documents:`);
      pendingDocuments.forEach(user => {
        console.log(`User ${user.id} (${user.username}):`, {
          documentType: user.documentType,
          documentStatus: user.documentStatus,
          hasDocumentFile: !!user.documentFile,
          documentFileLength: user.documentFile?.length || 0,
          submittedAt: user.documentSubmittedAt
        });
      });
      
      const safeDocuments = pendingDocuments.map(user => ({ ...user, password: undefined }));
      res.json(safeDocuments);
    } catch (error: any) {
      console.error('Error retrieving pending documents:', error);
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/admin/documents/:userId/approve", authenticateToken, requireRole('admin'), async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const reviewerId = req.user.id;
      
      const updatedUser = await storage.approveDocument(userId, reviewerId);
      res.json({ user: updatedUser, message: "Document approved" });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/admin/documents/:userId/reject", authenticateToken, requireRole('admin'), async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const reviewerId = req.user.id;
      
      const updatedUser = await storage.rejectDocument(userId, reviewerId);
      res.json({ user: updatedUser, message: "Document rejected" });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/admin/verify-business/:id", authenticateToken, requireRole('admin'), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const verifiedBusiness = await storage.verifyBusiness(id);
      if (verifiedBusiness) {
        res.json({ ...verifiedBusiness, password: undefined });
      } else {
        res.status(404).json({ message: "Business not found" });
      }
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/admin/reject-business/:id", authenticateToken, requireRole('admin'), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const rejected = await storage.rejectBusiness(id);
      if (rejected) {
        res.json({ message: "Business rejected and removed" });
      } else {
        res.status(404).json({ message: "Business not found or already verified" });
      }
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Public platform statistics for homepage
  app.get("/api/analytics/platform/stats", async (req, res) => {
    try {
      const stats = await storage.getPlatformStats();
      res.json(stats);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Analytics routes
  app.get("/api/analytics/merchant/:merchantId/revenue", authenticateToken, async (req, res) => {
    try {
      const merchantId = parseInt(req.params.merchantId);
      
      // Only allow merchants to view their own revenue or admins to view any
      if (req.user.role !== 'admin' && req.user.id !== merchantId) {
        return res.sendStatus(403);
      }
      
      const revenue = await storage.getMerchantRevenue(merchantId);
      res.json({ revenue });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/analytics/deal/:dealId/stats", authenticateToken, async (req, res) => {
    try {
      const dealId = parseInt(req.params.dealId);
      const stats = await storage.getDealStats(dealId);
      res.json(stats);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Merchant Portal API Routes
  
  // Get merchant's own deals
  app.get("/api/deals/my-deals", authenticateToken, requireRole('merchant'), async (req, res) => {
    try {
      // Get or create merchant record for this user
      let merchant = await storage.getMerchantByUserId(req.user.id);
      if (!merchant) {
        merchant = await storage.createMerchantFromUser(req.user);
      }
      
      const deals = await storage.getDealsByMerchant(merchant.id);
      res.json(deals);
    } catch (error) {
      console.error("Error fetching merchant deals:", error);
      res.status(500).json({ error: "Failed to fetch deals" });
    }
  });

  // Get comprehensive offers for merchant
  app.get("/api/offers/my-offers", authenticateToken, requireRole('merchant'), async (req, res) => {
    try {
      // Get or create merchant record for this user
      let merchant = await storage.getMerchantByUserId(req.user.id);
      if (!merchant) {
        merchant = await storage.createMerchantFromUser(req.user);
      }
      
      const offers = await storage.getOffersByMerchant(merchant.id);
      res.json(offers);
    } catch (error) {
      console.error('Error getting merchant offers:', error);
      res.status(500).json({ error: "Failed to fetch offers" });
    }
  });

  // Get single comprehensive offer details
  app.get("/api/offers/:id", authenticateToken, requireRole('merchant'), async (req, res) => {
    try {
      const offerId = req.params.id;
      const offer = await storage.getOffer(offerId);
      
      if (!offer) {
        return res.status(404).json({ error: "Offer not found" });
      }
      
      // Check if merchant owns this offer
      let merchant = await storage.getMerchantByUserId(req.user.id);
      if (!merchant || merchant.id !== offer.merchantId) {
        return res.status(403).json({ error: "Not authorized to view this offer" });
      }
      
      res.json(offer);
    } catch (error) {
      console.error('Error getting offer details:', error);
      res.status(500).json({ error: "Failed to fetch offer details" });
    }
  });

  // Update comprehensive offer
  app.put("/api/offers/:id", authenticateToken, requireRole('merchant'), async (req, res) => {
    try {
      const offerId = req.params.id;
      const updates = req.body;
      
      console.log('PUT /api/offers/:id - Raw updates received:', JSON.stringify(updates, null, 2));
      
      // Check each field type that could cause issues
      if (updates.tags) console.log('Tags type:', typeof updates.tags, Array.isArray(updates.tags), updates.tags);
      if (updates.daysOfWeek) console.log('DaysOfWeek type:', typeof updates.daysOfWeek, Array.isArray(updates.daysOfWeek), updates.daysOfWeek);
      if (updates.mealPeriods) console.log('MealPeriods type:', typeof updates.mealPeriods, Array.isArray(updates.mealPeriods), updates.mealPeriods);
      if (updates.timeSlots) console.log('TimeSlots type:', typeof updates.timeSlots, updates.timeSlots);
      
      // Validate using insertOfferSchema (partial)
      const validation = insertOfferSchema.partial().safeParse(updates);
      if (!validation.success) {
        console.error('Full validation error details:');
        validation.error.errors.forEach(error => {
          console.error(`  Field: ${error.path.join('.')} - ${error.message} - Received: ${typeof updates[error.path[0]]} ${JSON.stringify(updates[error.path[0]])}`);
        });
        return res.status(400).json({ 
          error: "Validation failed", 
          details: validation.error.errors 
        });
      }
      
      // Check if offer exists and merchant owns it
      const offer = await storage.getOffer(offerId);
      if (!offer) {
        return res.status(404).json({ error: "Offer not found" });
      }
      
      let merchant = await storage.getMerchantByUserId(req.user.id);
      if (!merchant || merchant.id !== offer.merchantId) {
        return res.status(403).json({ error: "Not authorized to update this offer" });
      }
      
      const updatedOffer = await storage.updateOffer(offerId, validation.data);
      res.json(updatedOffer);
    } catch (error) {
      console.error('Error updating offer:', error);
      res.status(500).json({ error: "Failed to update offer" });
    }
  });

  // Toggle comprehensive offer active status
  app.post("/api/offers/:id/toggle", authenticateToken, requireRole('merchant'), async (req, res) => {
    try {
      const offerId = req.params.id;
      
      // Check if offer exists and merchant owns it
      const offer = await storage.getOffer(offerId);
      if (!offer) {
        return res.status(404).json({ error: "Offer not found" });
      }
      
      let merchant = await storage.getMerchantByUserId(req.user.id);
      if (!merchant || merchant.id !== offer.merchantId) {
        return res.status(403).json({ error: "Not authorized to toggle this offer" });
      }
      
      const updatedOffer = await storage.updateOffer(offerId, { active: !offer.active });
      res.json(updatedOffer);
    } catch (error) {
      console.error('Error toggling offer:', error);
      res.status(500).json({ error: "Failed to toggle offer" });
    }
  });

  // Get redemptions for a merchant
  app.get("/api/redemptions/merchant/:merchantId?", authenticateToken, requireRole('merchant'), async (req, res) => {
    try {
      const merchantId = parseInt(req.params.merchantId);
      
      // Only allow merchants to view their own redemptions or admins to view any
      if (req.user.role !== 'admin' && req.user.id !== merchantId) {
        return res.sendStatus(403);
      }

      console.log('Fetching redemptions for merchant:', merchantId);
      
      // Get merchant's UUID for offers table lookup
      const merchant = await storage.getMerchantByUserId(merchantId);
      const merchantUuid = merchant?.id;

      // Use raw SQL to get ALL redemptions and filter by merchant later
      const redemptionResults = await db.execute(sql`
        SELECT 
          r.id,
          r.deal_id,
          r.user_id,
          r.redeemed_at,
          r.value,
          d.title as legacy_title,
          d.merchant_id as legacy_merchant_id,
          u.username as customer_name
        FROM redemptions r
        LEFT JOIN deals d ON r.deal_id = d.id
        LEFT JOIN users u ON r.user_id = u.id
        ORDER BY r.redeemed_at DESC
      `);

      // Filter to include only this merchant's redemptions
      const merchantRedemptions = [];
      
      for (const redemption of redemptionResults.rows) {
        let belongsToMerchant = false;
        let offerTitle = 'Unknown Offer';
        let offerData = null;
        
        // Check if it's a legacy deal redemption
        if (redemption.legacy_merchant_id === merchantId) {
          belongsToMerchant = true;
          offerTitle = redemption.legacy_title || 'Legacy Deal';
        } else {
          // Check if it's a UUID offer redemption by looking up the hashed deal_id
          const offers = await storage.getOffersByMerchant(merchantUuid);
          for (const offer of offers) {
            // Calculate the same hash we used when creating the redemption
            const offerHash = Math.abs(offer.id.split('-')[0].split('').reduce((a, b) => {
              a = ((a << 5) - a) + b.charCodeAt(0);
              return a & a;
            }, 0)) % 1000000;
            
            if (offerHash === parseInt(redemption.deal_id)) {
              belongsToMerchant = true;
              offerTitle = offer.title;
              offerData = offer; // Store the full offer data
              break;
            }
          }
        }
        
        if (belongsToMerchant) {
          merchantRedemptions.push({
            ...redemption,
            deal_title: offerTitle,
            offer_data: offerData // Include the offer data for pricing calculation
          });
        }
      }

      console.log('Found total redemptions:', redemptionResults.rows.length, 'merchant redemptions:', merchantRedemptions.length);

      // Transform data to match frontend expectations
      const formattedRedemptions = merchantRedemptions.map((redemption: any) => {
        const discountAmount = redemption.value ? parseFloat(redemption.value) : 0;
        
        let originalPrice = 'N/A';
        let finalPrice = '0.00';
        
        // If we have offer data, use it for accurate pricing
        if (redemption.offer_data) {
          const offer = redemption.offer_data;
          
          // For fixed price bundles, use the actual offer data
          if (offer.type === 'fixed_price_bundle' && offer.fixedPrice && offer.originalValue) {
            originalPrice = parseFloat(offer.originalValue).toFixed(2);
            // Show the offer value (what customer paid)
            finalPrice = parseFloat(offer.fixedPrice).toFixed(2);
          } 
          // For percentage discounts
          else if (offer.type === 'percentage_discount' && offer.percentOff && offer.originalValue) {
            originalPrice = parseFloat(offer.originalValue).toFixed(2);
            const discountAmount = (parseFloat(offer.originalValue) * parseFloat(offer.percentOff)) / 100;
            finalPrice = (parseFloat(offer.originalValue) - discountAmount).toFixed(2);
          }
          // For BOGO and free item offers
          else if (offer.type === 'bogo' || offer.type === 'free_item_with_purchase') {
            // For BOGO: show the discount amount as the value saved
            originalPrice = '0.00'; // BOGO doesn't have an "original price" - it's the discount
            finalPrice = discountAmount.toFixed(2); // Show the discount amount as the offer value
          }
          // Fallback to legacy calculation for other types
          else {
            originalPrice = parseFloat(offer.originalValue || 0).toFixed(2);
            finalPrice = parseFloat(offer.fixedPrice || offer.discountValue || 0).toFixed(2);
          }
        } 
        // Legacy calculation for deals without offer data
        else {
          // Try to determine if this is a percentage discount from the offer title
          const isPercentageDiscount = redemption.deal_title && redemption.deal_title.includes('%');
          
          if (isPercentageDiscount) {
            // Extract percentage from title (e.g., "50% off" -> 50)
            const percentMatch = redemption.deal_title.match(/(\d+)%/);
            if (percentMatch) {
              const percent = parseInt(percentMatch[1]);
              if (percent > 0 && percent < 100) {
                // Normal calculation: if discount is £200 and it's 50% off, original price is £400
                const calculatedOriginalPrice = discountAmount / (percent / 100);
                originalPrice = calculatedOriginalPrice.toFixed(2);
                finalPrice = (calculatedOriginalPrice - discountAmount).toFixed(2);
              }
            }
          }
        }
        
        return {
          id: redemption.id,
          offer_id: redemption.deal_id,
          user_id: redemption.user_id,
          redeemedAt: redemption.redeemed_at ? new Date(redemption.redeemed_at).toISOString() : new Date().toISOString(),
          createdAt: redemption.redeemed_at ? new Date(redemption.redeemed_at).toISOString() : new Date().toISOString(),
          value: finalPrice, // What was actually paid
          calculatedDiscount: discountAmount.toFixed(2), // Actual discount amount
          basketSubtotal: originalPrice, // Original price before discount
          // Add the fields the frontend expects
          offerValue: finalPrice, // What customer paid (offer value)
          originalValue: originalPrice, // Original price before discount
          voucher_code: `LEGACY-${redemption.id}`,
          dealTitle: redemption.deal_title || 'Unknown Deal',
          offerTitle: redemption.deal_title || 'Unknown Deal',
          customerName: redemption.customer_name || 'Guest',
          staffName: 'System'
        };
      });

      res.json(formattedRedemptions);
      
    } catch (error: any) {
      console.error('Error fetching merchant redemptions:', error);
      res.status(500).json({ message: "Failed to fetch redemptions", error: error.message });
    }
  });

  // Process voucher redemption
  app.post("/api/redemptions/redeem", authenticateToken, requireRole('merchant'), async (req, res) => {
    const { voucherCode, staffPin, basketAmount } = req.body;

    if (!voucherCode || !staffPin) {
      return res.status(400).json({ error: "Voucher code and staff PIN required" });
    }

    try {
      // Find the voucher to get deal details
      const voucher = await storage.getVoucherByNumber(voucherCode);
      if (!voucher) {
        return res.status(404).json({ error: "Voucher not found" });
      }

      // Check if voucher is already used
      if (voucher.isUsed) {
        return res.status(400).json({ error: "Voucher has already been redeemed" });
      }

      // Handle both legacy offers and UUID-based offers
      let offer = null;
      let isUuidOffer = false;
      
      if (voucher.dealId === -1) {
        // This is a UUID offer voucher - extract offer ID from voucherNumber
        const uuidMatch = voucher.voucherNumber.match(/^([0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12})-/i);
        
        if (uuidMatch) {
          const offerId = uuidMatch[1].toLowerCase();
          
          // Get offer from offers table
          const offerData = await storage.getOffer(offerId);
          if (!offerData) {
            return res.status(404).json({ error: "Offer not found" });
          }
          
          // Use offer structure directly
          offer = {
            id: offerData.id,
            merchantId: offerData.merchantId,
            title: offerData.title,
            type: offerData.type, // Keep the original type for proper logic
            discountType: offerData.type === 'percentage_discount' ? 'percentage' : 'fixed',
            discountValue: offerData.percentOff?.toString() || offerData.fixedPrice?.toString() || offerData.discountValue?.toString() || '0',
            originalValue: offerData.originalValue?.toString() || '0',
            percentOff: offerData.percentOff,
            fixedPrice: offerData.fixedPrice
          };
          isUuidOffer = true;
        } else {
          return res.status(400).json({ error: "Invalid voucher format" });
        }
      } else {
        // Legacy offer voucher (stored in deals table)
        const legacyOffer = await storage.getDeal(voucher.dealId);
        if (!legacyOffer) {
          return res.status(404).json({ error: "Offer not found" });
        }
        
        // Convert legacy deal to offer structure
        offer = {
          id: legacyOffer.id,
          merchantId: legacyOffer.merchantId,
          title: legacyOffer.title,
          discountType: legacyOffer.discountType,
          discountValue: legacyOffer.discountValue
        };
      }

      // Get merchant information to verify authorization
      const merchant = await storage.getMerchantByUserId(req.user.id);
      if (!merchant) {
        return res.status(403).json({ error: "Merchant not found" });
      }

      // Verify merchant owns this offer
      if (isUuidOffer) {
        // For UUID offers, compare with merchant UUID
        if (offer.merchantId !== merchant.id) {
          return res.status(403).json({ error: "Not authorized to redeem this voucher" });
        }
      } else {
        // For legacy offers, compare with user ID
        if (offer.merchantId !== req.user.id) {
          return res.status(403).json({ error: "Not authorized to redeem this voucher" });
        }
      }

      // Calculate discount
      const basketValue = basketAmount ? parseFloat(basketAmount) : 0;
      let discountValue = 0;
      
      if (offer.discountType === 'percentage') {
        discountValue = basketValue * (parseFloat(offer.discountValue || '0') / 100);
      } else if (offer.type === 'bogo' || offer.type === 'free_item_with_purchase') {
        // For BOGO offers, use the configured discount value or calculate from original value
        const offerData = await storage.getOffer(offer.id);
        
        if (offerData?.discountValue) {
          discountValue = parseFloat(offerData.discountValue);
        } else if (offerData?.originalValue) {
          discountValue = parseFloat(offerData.originalValue) / 2; // BOGO = 50% off
        } else {
          discountValue = basketValue / 2; // Fallback to 50% of basket
        }
      } else {
        discountValue = parseFloat(offer.discountValue || '0');
      }

      const finalValue = Math.max(0, basketValue - discountValue);

      // Since the current system uses legacy offers table, let's mark the voucher as used
      // This tracks the redemption in the existing vouchers table

      // Mark voucher as used
      await storage.useVoucher(voucherCode);
      
      // Create redemption record in legacy format
      // For UUID offers, we need to use a fake deal ID since the legacy table expects integers
      // We'll use a hash of the UUID to create a consistent integer ID
      let legacyDealId = voucher.dealId;
      if (voucher.dealId === -1) {
        // Create a consistent integer from UUID for legacy compatibility
        legacyDealId = Math.abs(offer.id.split('-')[0].split('').reduce((a, b) => {
          a = ((a << 5) - a) + b.charCodeAt(0);
          return a & a;
        }, 0)) % 1000000; // Keep it reasonable size
      }
      
      // Calculate the correct value for redemption record (what customer actually paid - the offer value)
      let redemptionValue = discountValue;
      if (offer.type === 'bogo' || offer.type === 'free_item_with_purchase') {
        // For BOGO: show the discount value (what they saved), not what they paid
        redemptionValue = offer.discountValue ? parseFloat(offer.discountValue) : (offer.originalValue ? parseFloat(offer.originalValue) / 2 : discountValue);
      } else if (offer.type === 'fixed_price_bundle') {
        // For fixed price bundles: show the offer value (what customer paid)
        redemptionValue = offer.fixedPrice ? parseFloat(offer.fixedPrice) : discountValue;
      }
      
      await storage.createLegacyRedemption({
        dealId: legacyDealId,
        userId: voucher.userId,
        value: redemptionValue,
      });

      // Increment usage count for the offer
      try {
        await storage.incrementOfferUsage(offer.id);
      } catch (usageError) {
        console.error('Error incrementing offer usage:', usageError);
        // Continue with redemption even if usage increment fails
      }

      // Award loyalty points for the redemption
      try {
        // Calculate the correct value for loyalty points (what customer actually paid)
        let loyaltyEarnAmount = basketValue;
        if (offer.type === 'fixed_price_bundle' && offer.fixedPrice) {
          // For fixed price bundles, use the offer value (what customer paid)
          loyaltyEarnAmount = parseFloat(offer.fixedPrice);
        } else if (offer.type === 'percentage_discount' && offer.percentOff && offer.originalValue) {
          // For percentage discounts, calculate what customer paid
          const discountAmount = (parseFloat(offer.originalValue) * parseFloat(offer.percentOff)) / 100;
          loyaltyEarnAmount = parseFloat(offer.originalValue) - discountAmount;
        } else if (offer.type === 'bogo' || offer.type === 'free_item_with_purchase') {
          // For BOGO and free item offers, use the original value (what customer paid for the full items)
          loyaltyEarnAmount = offer.originalValue ? parseFloat(offer.originalValue) : basketValue;
        } else {
          // Fallback for other types
          loyaltyEarnAmount = Math.max(basketValue, parseFloat(offer.fixedPrice || offer.discountValue || '0'));
        }

        const loyaltyResult = await awardLoyaltyPoints({
          merchantId: getMerchantId(req), // Use integer merchant ID, not UUID
          userId: voucher.userId,
          basketValue: loyaltyEarnAmount,
          redemptionValue: loyaltyEarnAmount,
          type: 'purchase'
        });
        console.log('Loyalty points awarded:', loyaltyResult);
      } catch (loyaltyError) {
        console.error('Error awarding loyalty points:', loyaltyError);
        // Continue with redemption even if loyalty fails
      }
      
      res.json({
        success: true,
        discount: discountValue.toFixed(2),
        finalValue: finalValue.toFixed(2),
        message: "Voucher redeemed successfully"
      });
    } catch (error) {
      console.error("Error redeeming voucher:", error);
      res.status(500).json({ error: "Failed to redeem voucher" });
    }
  });

  // Migration endpoint to update usage counts from historic redemptions
  app.post("/api/admin/migrate-usage-counts", authenticateToken, async (req, res) => {
    try {
      console.log('Starting usage count migration from historic redemptions...');
      
      // Get all redemptions grouped by dealId (which maps to offer)
      const redemptionCounts = await db
        .select({
          dealId: redemptions.dealId,
          count: sql<number>`COUNT(*)`
        })
        .from(redemptions)
        .groupBy(redemptions.dealId);
      
      console.log(`Found ${redemptionCounts.length} offers with historic redemptions`);
      
      let updated = 0;
      let errors = 0;
      
      for (const redemptionCount of redemptionCounts) {
        try {
          // For legacy deals (integer IDs), we need to find the corresponding offer
          // For now, let's focus on offers with UUID format (dealId = -1 indicates offer system)
          if (redemptionCount.dealId === -1) {
            // These are comprehensive offers, but we need to map them differently
            console.log('Skipping dealId -1 (needs special handling)');
            continue;
          }
          
          // Try to find offer by the legacy mapping
          // The redemption dealId might map to an offer's ID in some cases
          const count = Number(redemptionCount.count);
          
          // Look for offers that might correspond to this dealId
          // In the current system, we need to identify which offers these belong to
          console.log(`Processing dealId ${redemptionCount.dealId} with ${count} redemptions`);
          
          // For now, let's update offers by checking vouchers table to find the mapping
          const relatedVouchers = await db
            .select({ 
              voucherNumber: vouchers.voucherNumber,
              dealId: vouchers.dealId 
            })
            .from(vouchers)
            .where(eq(vouchers.dealId, redemptionCount.dealId))
            .limit(1);
          
          if (relatedVouchers.length > 0) {
            // Extract offer ID from voucher number if it follows the UUID pattern
            const voucherNumber = relatedVouchers[0].voucherNumber;
            const uuidMatch = voucherNumber.match(/([0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12})/i);
            
            if (uuidMatch) {
              const offerId = uuidMatch[1].toLowerCase();
              console.log(`Mapping dealId ${redemptionCount.dealId} to offer ${offerId}`);
              
              // Update the offer usage count
              const result = await db
                .update(offers)
                .set({ 
                  usageCount: count,
                  updatedAt: new Date()
                })
                .where(eq(offers.id, offerId));
              
              if (result.rowCount && result.rowCount > 0) {
                console.log(`Updated offer ${offerId} usage count to ${count}`);
                updated++;
              } else {
                console.log(`Offer ${offerId} not found or not updated`);
              }
            }
          }
          
        } catch (error: any) {
          console.error(`Error updating dealId ${redemptionCount.dealId}:`, error.message);
          errors++;
        }
      }
      
      console.log(`Migration completed: ${updated} offers updated, ${errors} errors`);
      
      res.json({
        success: true,
        message: `Usage count migration completed: ${updated} offers updated, ${errors} errors`,
        updated,
        errors,
        totalProcessed: redemptionCounts.length
      });
      
    } catch (error: any) {
      console.error('Error in usage count migration:', error);
      res.status(500).json({ 
        error: "Failed to migrate usage counts",
        message: error.message 
      });
    }
  });

  // Generate QR code for offer
  app.post("/api/offers/generate-qr", authenticateToken, requireRole('merchant'), async (req, res) => {
    const { offerId } = req.body;

    if (!offerId) {
      return res.status(400).json({ error: "Offer ID required" });
    }

    try {
      const qrData = `OFFER:${offerId}:${Date.now()}`;
      
      res.json({
        qrCode: qrData,
        offerId: offerId,
        generatedAt: new Date().toISOString()
      });
    } catch (error) {
      console.error("Error generating QR code:", error);
      res.status(500).json({ error: "Failed to generate QR code" });
    }
  });

  // Toggle offer active status
  app.post("/api/merchant/offers/:id/toggle", authenticateToken, requireRole('merchant'), async (req, res) => {
    try {
      const dealId = parseInt(req.params.id);
      
      // Get current deal and verify ownership
      const existingDeal = await storage.getDeal(dealId);
      if (!existingDeal) {
        return res.status(404).json({ message: "Offer not found" });
      }
      
      if (existingDeal.merchantId !== req.user.id) {
        return res.status(403).json({ message: "Not authorized to modify this offer" });
      }
      
      // Toggle the active status
      const updatedDeal = await storage.updateDeal(dealId, { 
        isActive: !existingDeal.isActive 
      });
      
      res.json(updatedDeal);
    } catch (error: any) {
      console.error('Deal toggle error:', error);
      res.status(500).json({ message: error.message || "Failed to toggle offer" });
    }
  });

  // Get single offer by ID for merchant
  app.get("/api/merchant/offers/:id", authenticateToken, requireRole('merchant'), async (req, res) => {
    try {
      const dealId = parseInt(req.params.id);
      
      const deal = await storage.getDeal(dealId);
      if (!deal) {
        return res.status(404).json({ message: "Offer not found" });
      }
      
      if (deal.merchantId !== req.user.id && req.user.role !== 'admin') {
        return res.status(403).json({ message: "Not authorized to view this offer" });
      }
      
      res.json(deal);
    } catch (error: any) {
      console.error('Error fetching offer:', error);
      res.status(500).json({ message: error.message || "Failed to fetch offer" });
    }
  });

  // Update offer for merchant with proper validation
  app.put("/api/merchant/offers/:id", authenticateToken, requireRole('merchant'), async (req, res) => {
    try {
      const dealId = parseInt(req.params.id);
      
      // Check if deal exists and belongs to the merchant
      const existingDeal = await storage.getDeal(dealId);
      if (!existingDeal) {
        return res.status(404).json({ message: "Offer not found" });
      }
      
      if (existingDeal.merchantId !== req.user.id) {
        return res.status(403).json({ message: "Not authorized to update this offer" });
      }
      
      // Process the update data
      const processedData = {
        ...req.body
      };
      
      // Convert expiryDate if provided
      if (req.body.expiryDate) {
        processedData.expiryDate = new Date(req.body.expiryDate);
      }
      
      // Validate the data
      const dealData = insertDealSchema.partial().parse(processedData);
      
      const updatedDeal = await storage.updateDeal(dealId, dealData);
      
      res.json(updatedDeal);
    } catch (error: any) {
      console.error('Deal update validation error:', error);
      res.status(400).json({ message: error.message });
    }
  });

  // LOYALTY PROGRAM ENDPOINTS
  
  // Loyalty tiers storage (empty initially)
  let loyaltyTiers: any[] = [];

  // Get merchant's loyalty program
  app.get("/api/loyalty/program", async (req, res) => {
    try {
      const merchantId = 32;
      const existingProgram = await storage.getLoyaltyProgram(merchantId);
      
      if (existingProgram) {
        // Fetch real tiers from database
        const tiersResult = await db.execute(sql`
          SELECT id, name, threshold_points, discount_percent, color, sort_order, points_multiplier
          FROM loyalty_tiers 
          WHERE program_id = ${existingProgram.id}
          ORDER BY sort_order
        `);
        
        const tiers = tiersResult.rows.map((tier: any) => ({
          id: tier.id,
          name: tier.name,
          thresholdPoints: tier.threshold_points,
          discountPercent: tier.discount_percent,
          color: tier.color,
          sortOrder: tier.sort_order,
          pointsMultiplier: parseFloat(tier.points_multiplier)
        }));
        
        const programWithTiers = {
          ...existingProgram,
          tiers,
          rewards: []
        };
        res.json(programWithTiers);
      } else {
        // Create a default program if none exists
        const defaultProgram = {
          merchantId: merchantId,
          model: "points" as const,
          pointsPerCurrency: 10,
          minBasketEarn: "5.00",
          earnCooldownMinutes: 30,
          dailyEarnCap: 3,
          active: true,
        };
        
        const newProgram = await storage.createLoyaltyProgram(defaultProgram);
        const programWithTiers = {
          ...newProgram,
          tiers: [],
          rewards: []
        };
        res.json(programWithTiers);
      }
    } catch (error) {
      console.error('Get loyalty program error:', error);
      res.status(500).json({ error: "Failed to fetch loyalty program" });
    }
  });

  // Create/Update loyalty program
  app.post("/api/loyalty/program", authenticateToken, async (req, res) => {
    try {
      const merchantId = req.user.merchantId || req.user.id;
      
      // Filter out fields that shouldn't be updated (like timestamps, id, etc.)
      const updateData = {
        model: req.body.model,
        pointsPerCurrency: req.body.pointsPerCurrency,
        minBasketEarn: req.body.minBasketEarn,
        earnCooldownMinutes: req.body.earnCooldownMinutes,
        dailyEarnCap: req.body.dailyEarnCap,
        stackingAllowed: req.body.stackingAllowed,
        expiryDays: req.body.expiryDays,
        active: req.body.active,
      };
      
      // Update the existing program
      const updatedProgram = await storage.updateLoyaltyProgram(merchantId, updateData);
      
      if (updatedProgram) {
        console.log('Updated loyalty program for merchant', merchantId, ':', updatedProgram);
        res.json({ success: true, program: updatedProgram });
      } else {
        res.status(404).json({ error: "Loyalty program not found" });
      }
    } catch (error) {
      console.error('Update loyalty program error:', error);
      res.status(500).json({ error: "Failed to save loyalty program" });
    }
  });

  // Add new tier
  app.post("/api/loyalty/tiers", authenticateToken, async (req, res) => {
    try {
      if (req.user?.role !== "merchant") {
        return res.status(403).json({ error: "Access denied" });
      }

      const { name, thresholdPoints, perks, color, pointsMultiplier } = req.body;
      
      // Create new tier and add to mock data
      const newTier = {
        id: `tier-${Date.now()}`,
        name: name || "New Tier",
        thresholdPoints: thresholdPoints || 0,
        perks: perks || [{ type: "percentOff", value: 5 }],
        color: color,
        pointsMultiplier: pointsMultiplier || 1.0
      };

      // Add to loyalty tiers array
      loyaltyTiers.push(newTier);

      res.json({ success: true, tier: newTier });
    } catch (error) {
      console.error("Error adding tier:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Update tier
  app.put("/api/loyalty/tiers/:tierId", authenticateToken, async (req, res) => {
    try {
      if (req.user?.role !== "merchant") {
        return res.status(403).json({ error: "Access denied" });
      }

      const { tierId } = req.params;
      const { name, thresholdPoints, perks, color, pointsMultiplier } = req.body;
      
      // Find and update tier in loyalty data
      const tierIndex = loyaltyTiers.findIndex(tier => tier.id === tierId);
      if (tierIndex !== -1) {
        loyaltyTiers[tierIndex] = {
          id: tierId,
          name,
          thresholdPoints,
          perks,
          color,
          pointsMultiplier: pointsMultiplier || loyaltyTiers[tierIndex].pointsMultiplier || 1.0
        };
      }

      res.json({ success: true, tier: loyaltyTiers[tierIndex] });
    } catch (error) {
      console.error("Error updating tier:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Delete tier
  app.delete("/api/loyalty/tiers/:tierId", authenticateToken, async (req, res) => {
    try {
      if (req.user?.role !== "merchant") {
        return res.status(403).json({ error: "Access denied" });
      }

      const { tierId } = req.params;
      
      // Remove tier from loyalty data
      const tierIndex = loyaltyTiers.findIndex(tier => tier.id === tierId);
      if (tierIndex !== -1) {
        loyaltyTiers.splice(tierIndex, 1);
      }
      
      res.json({ success: true, deletedTierId: tierId });
    } catch (error) {
      console.error("Error deleting tier:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Recalculate all member tiers for a merchant
  app.post("/api/loyalty/recalculate-tiers", authenticateToken, async (req, res) => {
    try {
      if (req.user?.role !== "merchant") {
        return res.status(403).json({ error: "Access denied" });
      }

      const merchantId = req.user.id;
      const { reason } = req.body;
      
      console.log(`Starting tier recalculation for merchant ${merchantId}`);
      
      const result = await storage.recalculateAllMemberTiers(
        merchantId, 
        reason || "Manual tier recalculation triggered"
      );
      
      if (!result.success) {
        return res.status(400).json({ 
          error: result.error || "Failed to recalculate tiers",
          result 
        });
      }

      res.json({
        success: true,
        ...result,
        message: `Tier recalculation completed. ${result.updatedMembers} of ${result.totalMembers} members had tier changes.`
      });
    } catch (error) {
      console.error("Error recalculating tiers:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // User loyalty memberships endpoint
  app.get("/api/loyalty/user-memberships", authenticateToken, async (req, res) => {
    try {
      const userId = req.user?.id;
      if (!userId) {
        return res.status(401).json({ error: "Unauthorized" });
      }

      // Get all loyalty balances for this user with merchant and tier info
      const balances = await db.execute(sql`
        SELECT 
          lb.id,
          lb.balance as points,
          0 as stamps,
          lb.updated_at as last_activity,
          lp.model,
          m.name as program_name,
          lt.id as tier_id,
          lt.name as tier_name,
          lt.color as tier_color,
          lt.threshold_points,
          lt.discount_percent,
          lt.points_multiplier,
          m.name as business_name,
          'General' as business_category,
          m.id as merchant_id
        FROM loyalty_balances lb
        JOIN loyalty_programs lp ON lb.merchant_id = lp.merchant_id
        JOIN merchants m ON (
          CASE lp.merchant_id
            WHEN 1001 THEN '52e9f857-5b2f-4164-b266-b7c1b86267dd'
            WHEN 1002 THEN '4949dea8-6956-494c-a43b-47d568eeb481'
            ELSE m.id::text
          END
        ) = m.id::text
        LEFT JOIN loyalty_tiers lt ON lb.tier = lt.id::text
        WHERE lb.user_id = ${userId}
        AND lb.balance > 0
        ORDER BY lb.updated_at DESC
      `);

      // For each membership, we need to also get the next tier information
      const membershipsWithNextTier = await Promise.all(balances.rows.map(async (row: any) => {
        let nextTier = null;
        if (row.tier_id && row.threshold_points !== undefined) {
          // Get next tier in the same program
          const nextTierResult = await db.execute(sql`
            SELECT id, name, color, threshold_points, discount_percent, points_multiplier
            FROM loyalty_tiers 
            WHERE program_id = (SELECT program_id FROM loyalty_tiers WHERE id = ${row.tier_id})
            AND threshold_points > ${row.threshold_points}
            ORDER BY threshold_points ASC
            LIMIT 1
          `);
          if (nextTierResult.rows.length > 0) {
            const next = nextTierResult.rows[0];
            nextTier = {
              id: next.id,
              name: next.name,
              color: next.color,
              thresholdPoints: next.threshold_points,
              discountPercent: next.discount_percent,
              pointsMultiplier: parseFloat(next.points_multiplier)
            };
          }
        }

        return {
          id: row.id,
          programName: row.program_name,
          businessName: row.business_name,
          businessCategory: row.business_category,
          model: row.model,
          pointsBalance: row.points || 0,
          stampsBalance: row.stamps || 0,
          lastActivity: row.last_activity,
          merchantId: row.merchant_id,
          tier: row.tier_id ? {
            id: row.tier_id,
            name: row.tier_name,
            color: row.tier_color,
            thresholdPoints: row.threshold_points,
            discountPercent: row.discount_percent,
            pointsMultiplier: parseFloat(row.points_multiplier || '1.0')
          } : null,
          nextTier,
          // Add mock data for pricing - in real implementation this would come from database
          pointPrice: 0.10, // £0.10 per point for upgrade
          tierExpiresAt: row.tier_id ? new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString() : null // 1 year from now
        };
      }));

      res.json({ success: true, memberships: membershipsWithNextTier });
    } catch (error) {
      console.error("Error fetching user loyalty memberships:", error);
      res.status(500).json({ error: "Failed to fetch loyalty memberships" });
    }
  });

  // Get customer loyalty balance
  app.get("/api/loyalty/balance/:merchantId", authenticateToken, async (req, res) => {
    try {
      const merchantName = req.params.merchantId;
      const userId = req.user?.id;
      
      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }

      // Get loyalty balance for this user and merchant by name
      const result = await db.execute(sql`
        SELECT 
          lb.balance as points, 
          0 as stamps, 
          lt.name as tier_name
        FROM loyalty_balances lb
        JOIN users u ON lb.merchant_id = u.id
        LEFT JOIN loyalty_tiers lt ON lb.tier = lt.id::text
        WHERE lb.user_id = ${userId}
        AND u.business_name = ${merchantName}
        LIMIT 1
      `);

      if (result.rows.length > 0) {
        const row = result.rows[0];
        res.json({
          points: row.points || 0,
          stamps: row.stamps || 0,
          tier: row.tier_name || null
        });
      } else {
        res.json({
          points: 0,
          stamps: 0,
          tier: null
        });
      }
      return;
      
      // Get user's loyalty balance from database using raw query to match existing table structure
      const balanceResult = await db.execute(sql`
        SELECT points, stamps, tier_id FROM loyalty_balances 
        WHERE user_id = ${userId} AND merchant_id = ${merchantId}::text
      `);
      
      if (!balanceResult.rows.length) {
        // No balance found, return zero balance
        res.json({
          points: 0,
          stamps: 0,
          tier: null
        });
        return;
      }
      
      const balance = balanceResult.rows[0] as { points: number; stamps: number; tier_id: number | null };
      
      // Get tier information
      let tierInfo = null;
      if (balance.tier_id) {
        const tierResult = await db.execute(sql`
          SELECT name, discount_percent FROM loyalty_tiers 
          WHERE id = ${balance.tier_id}
        `);
        
        if (tierResult.rows.length) {
          const tier = tierResult.rows[0] as { name: string; discount_percent: number };
          tierInfo = {
            name: tier.name,
            perks: [
              {
                type: "discount",
                value: tier.discount_percent,
                note: "on all purchases"
              }
            ]
          };
        }
      }
      
      res.json({
        points: balance.points || 0,
        stamps: balance.stamps || 0,
        tier: tierInfo
      });
    } catch (error) {
      console.error('Get loyalty balance error:', error);
      res.status(500).json({ error: "Failed to fetch loyalty balance" });
    }
  });

  // Earn points/stamps (staff endpoint)
  app.post("/api/loyalty/earn", authenticateToken, async (req, res) => {
    try {
      const { customerId, basketAmount, earnType, notes } = req.body;
      const merchantId = req.user.merchantId || req.user.id;
      
      if (!customerId) {
        return res.status(400).json({ error: "Customer ID is required" });
      }

      // Calculate points to award
      const basketValue = parseFloat(basketAmount) || 0;
      const pointsPerPound = 10; // Default rate
      const pointsToAdd = earnType === 'purchase' ? Math.floor(basketValue * pointsPerPound) : 5; // 5 points for visit
      
      if (pointsToAdd <= 0) {
        return res.status(400).json({ error: "No points to award" });
      }

      // Award the points
      const loyaltyResult = await awardLoyaltyPoints({
        merchantId,
        userId: parseInt(customerId),
        basketValue,
        redemptionValue: Math.max(basketValue, 0),
        type: earnType
      });

      // For now, simulate tier change detection (would be improved with actual database logic)
      const tierChanged = loyaltyResult.pointsAdded >= 50; // Simulate tier change
      const newTier = tierChanged ? 'Bronze' : null;
      
      res.json({ 
        success: true, 
        pointsAdded: loyaltyResult.pointsAdded || pointsToAdd,
        stampsAdded: loyaltyResult.stampsAdded || 0,
        tierChanged,
        newTier,
        newBalance: { 
          points: loyaltyResult.pointsAdded || pointsToAdd, 
          stamps: loyaltyResult.stampsAdded || 0,
          tier: newTier ? { name: newTier } : null
        }
      });
    } catch (error) {
      console.error('Earn loyalty error:', error);
      res.status(500).json({ error: "Failed to process earning" });
    }
  });

  // Redeem reward
  app.post("/api/loyalty/redeem", authenticateToken, async (req, res) => {
    try {
      const { rewardId } = req.body;
      
      // Loyalty redemption (real implementation would update database)
      res.json({ 
        success: true, 
        message: "Reward redeemed successfully!",
        pointsDeducted: 50
      });
    } catch (error) {
      console.error('Redeem reward error:', error);
      res.status(500).json({ error: "Failed to redeem reward" });
    }
  });

  // Get loyalty events/history  
  app.get("/api/loyalty/events/:merchantId", authenticateToken, async (req, res) => {
    try {
      // Return mock data for now to avoid database errors
      res.json([]);
      return;
      
      // Get recent redemptions as loyalty events using raw query
      const redemptionsResult = await db.execute(sql`
        SELECT id, "discountValue", "createdAt"
        FROM redemptions 
        WHERE "userId" = ${userId} AND "merchantId" = ${merchantId}::text
        ORDER BY "createdAt" DESC 
        LIMIT 10
      `);
      
      const events = redemptionsResult.rows.map((redemption: any) => ({
        id: redemption.id.toString(),
        type: "earn_points",
        amount: Math.floor(parseFloat(redemption.discountValue || '0') * 10), // 10 points per £1
        createdAt: redemption.createdAt,
        metadata: { source: 'purchase' }
      }));
      
      res.json(events);
    } catch (error) {
      console.error('Get loyalty events error:', error);
      res.status(500).json({ error: "Failed to fetch loyalty events" });
    }
  });

  // Loyalty Members Management Routes
  app.get("/api/loyalty/members", async (req, res) => {
    try {
      // For debugging - use merchant ID 32 when no auth
      const merchantId = 32;
      
      // Get all loyalty members for this merchant with their balances, tiers, and user info
      const members = await storage.getLoyaltyMembers(merchantId);
      
      res.json({ success: true, members });
    } catch (error) {
      console.error("Error fetching loyalty members:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/loyalty/members/award-points", authenticateToken, async (req, res) => {
    try {
      if (req.user?.role !== "merchant") {
        return res.status(403).json({ error: "Access denied" });
      }

      const { userId, points, reason } = req.body;
      const merchantId = req.user.id;
      
      if (!userId || !points || points <= 0) {
        return res.status(400).json({ error: "Valid userId and positive points required" });
      }

      // Award points and create event
      const result = await storage.awardLoyaltyPoints(merchantId, userId, points, reason || "Manual adjustment by merchant");
      
      res.json({ success: true, result });
    } catch (error) {
      console.error("Error awarding points:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/loyalty/members/collect-points", authenticateToken, async (req, res) => {
    try {
      if (req.user?.role !== "merchant") {
        return res.status(403).json({ error: "Access denied" });
      }

      const { userId, basketAmount } = req.body;
      const merchantId = req.user.id;
      
      if (!userId || !basketAmount || basketAmount <= 0) {
        return res.status(400).json({ error: "Valid userId and basket amount required" });
      }

      // Calculate and award points based on programme settings
      const result = await storage.collectPointsFromTransaction(merchantId, userId, basketAmount);
      
      res.json({ success: true, result });
    } catch (error) {
      console.error("Error collecting points from transaction:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Revenue Impact Analytics
  app.get("/api/loyalty/revenue-impact", async (req, res) => {
    try {
      // For debugging - use merchant ID 32 when no auth
      const merchantId = 32;
      
      // Get current date for calculations
      const now = new Date();
      const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      const startOfYear = new Date(now.getFullYear(), 0, 1);
      
      // Get merchant's UUID for offers table lookup
      const merchant = await storage.getMerchantByUserId(merchantId);
      const merchantUuid = merchant?.id;
      
      // Get ALL redemptions and filter by merchant logic (same as redemptions endpoint)
      const redemptionResults = await db.execute(sql`
        SELECT 
          r.id,
          r.deal_id,
          r.value,
          r.redeemed_at,
          d.title as legacy_title,
          d.merchant_id as legacy_merchant_id
        FROM redemptions r
        LEFT JOIN deals d ON r.deal_id = d.id
        WHERE r.value IS NOT NULL
        ORDER BY r.redeemed_at DESC
      `);
      
      // Filter redemptions to include only this merchant's, using same logic as redemptions endpoint
      let totalImpact = 0;
      let monthImpact = 0;
      let yearImpact = 0;
      
      for (const redemption of redemptionResults.rows) {
        let belongsToMerchant = false;
        let offerData = null;
        
        // Check if it's a legacy deal redemption
        if (redemption.legacy_merchant_id === merchantId) {
          belongsToMerchant = true;
        } else {
          // Check if it's a UUID offer redemption by looking up the hashed deal_id
          const offers = await storage.getOffersByMerchant(merchantUuid);
          for (const offer of offers) {
            // Calculate the same hash we used when creating the redemption
            const offerHash = Math.abs(offer.id.split('-')[0].split('').reduce((a, b) => {
              a = ((a << 5) - a) + b.charCodeAt(0);
              return a & a;
            }, 0)) % 1000000;
            
            if (offerHash === parseInt(redemption.deal_id)) {
              belongsToMerchant = true;
              offerData = offer; // Store the full offer data for accurate pricing
              break;
            }
          }
        }
        
        if (belongsToMerchant) {
          // Calculate correct revenue value (what customer paid)
          let revenueValue = 0;
          
          if (offerData) {
            // For fixed price bundles, use the offer value (what customer paid)
            if (offerData.type === 'fixed_price_bundle' && offerData.fixedPrice) {
              revenueValue = parseFloat(offerData.fixedPrice);
            } 
            // For percentage discounts
            else if (offerData.type === 'percentage_discount' && offerData.percentOff && offerData.originalValue) {
              const discountAmount = (parseFloat(offerData.originalValue) * parseFloat(offerData.percentOff)) / 100;
              revenueValue = parseFloat(offerData.originalValue) - discountAmount;
            }
            // Fallback for other types
            else {
              revenueValue = parseFloat(offerData.fixedPrice || offerData.discountValue || redemption.value || 0);
            }
          } else {
            // Legacy calculation for deals without offer data
            revenueValue = parseFloat(redemption.value) || 0;
          }
          
          totalImpact += revenueValue;
          
          // Check if within current month
          if (redemption.redeemed_at && new Date(redemption.redeemed_at) >= startOfMonth) {
            monthImpact += revenueValue;
          }
          
          // Check if within current year
          if (redemption.redeemed_at && new Date(redemption.redeemed_at) >= startOfYear) {
            yearImpact += revenueValue;
          }
        }
      }
      
      const revenueImpact = {
        total: totalImpact,
        monthToDate: monthImpact,
        yearToDate: yearImpact
      };
      
      res.json({ success: true, revenueImpact });
    } catch (error) {
      console.error("Error fetching revenue impact:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Week-over-week analytics for all metrics
  app.get("/api/loyalty/analytics/wow", async (req, res) => {
    try {
      // For debugging - use merchant ID 32 when no auth
      const merchantId = 32;
      
      // Get current date ranges
      const now = new Date();
      const startOfThisWeek = new Date(now.getFullYear(), now.getMonth(), now.getDate() - now.getDay());
      const startOfLastWeek = new Date(startOfThisWeek.getTime() - 7 * 24 * 60 * 60 * 1000);
      const endOfLastWeek = new Date(startOfThisWeek.getTime() - 1);
      
      const { pool } = await import('./db');
      
      // Get current week metrics
      const [currentMembersResult, currentPointsResult, currentRedemptionsResult, currentRevenueResult] = await Promise.all([
        pool.query(`
          SELECT COUNT(*) as member_count
          FROM loyalty_balances lb 
          JOIN users u ON lb.user_id = u.id 
          WHERE lb.merchant_id = $1 
          AND lb.created_at >= $2
        `, [merchantId, startOfThisWeek.toISOString()]),
        
        pool.query(`
          SELECT COALESCE(SUM(CAST(amount AS DECIMAL)), 0) as total_points
          FROM loyalty_events 
          WHERE merchant_id = $1 
          AND type = 'earn_points'
          AND created_at >= $2
        `, [merchantId, startOfThisWeek.toISOString()]),
        
        // Simplified redemption count for now - redemptions table doesn't have merchant_id
        pool.query(`
          SELECT 0 as redemption_count
        `),
        
        // Simplified revenue impact for now - using the dedicated endpoint instead
        pool.query(`
          SELECT 0 as revenue_impact
        `)
      ]);
      
      // Get last week metrics
      const [lastMembersResult, lastPointsResult, lastRedemptionsResult, lastRevenueResult] = await Promise.all([
        pool.query(`
          SELECT COUNT(*) as member_count
          FROM loyalty_balances lb 
          JOIN users u ON lb.user_id = u.id 
          WHERE lb.merchant_id = $1 
          AND lb.created_at >= $2 
          AND lb.created_at <= $3
        `, [merchantId, startOfLastWeek.toISOString(), endOfLastWeek.toISOString()]),
        
        pool.query(`
          SELECT COALESCE(SUM(CAST(amount AS DECIMAL)), 0) as total_points
          FROM loyalty_events 
          WHERE merchant_id = $1 
          AND type = 'earn_points'
          AND created_at >= $2 
          AND created_at <= $3
        `, [merchantId, startOfLastWeek.toISOString(), endOfLastWeek.toISOString()]),
        
        // Simplified last week redemption count
        pool.query(`
          SELECT 0 as redemption_count
        `),
        
        // Simplified last week revenue impact
        pool.query(`
          SELECT 0 as revenue_impact
        `)
      ]);
      
      // Calculate percentage changes
      const currentMembers = parseInt(currentMembersResult.rows[0]?.member_count || 0);
      const lastMembers = parseInt(lastMembersResult.rows[0]?.member_count || 0);
      const membersGrowth = lastMembers > 0 ? ((currentMembers - lastMembers) / lastMembers * 100) : 0;
      
      const currentPoints = parseFloat(currentPointsResult.rows[0]?.total_points || 0);
      const lastPoints = parseFloat(lastPointsResult.rows[0]?.total_points || 0);
      const pointsGrowth = lastPoints > 0 ? ((currentPoints - lastPoints) / lastPoints * 100) : 0;
      
      const currentRedemptions = parseInt(currentRedemptionsResult.rows[0]?.redemption_count || 0);
      const lastRedemptions = parseInt(lastRedemptionsResult.rows[0]?.redemption_count || 0);
      const redemptionsGrowth = lastRedemptions > 0 ? ((currentRedemptions - lastRedemptions) / lastRedemptions * 100) : 0;
      
      const currentRevenue = parseFloat(currentRevenueResult.rows[0]?.revenue_impact || 0);
      const lastRevenue = parseFloat(lastRevenueResult.rows[0]?.revenue_impact || 0);
      const revenueGrowth = lastRevenue > 0 ? ((currentRevenue - lastRevenue) / lastRevenue * 100) : 0;
      
      const analytics = {
        members: {
          current: currentMembers,
          growth: parseFloat(membersGrowth.toFixed(1))
        },
        points: {
          current: currentPoints,
          growth: parseFloat(pointsGrowth.toFixed(1))
        },
        redemptions: {
          current: currentRedemptions,
          growth: parseFloat(redemptionsGrowth.toFixed(1))
        },
        revenue: {
          current: currentRevenue,
          growth: parseFloat(revenueGrowth.toFixed(1))
        }
      };
      
      res.json({ success: true, analytics });
    } catch (error) {
      console.error("Error fetching WoW analytics:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.put("/api/loyalty/members/:userId/tier", authenticateToken, async (req, res) => {
    try {
      if (req.user?.role !== "merchant") {
        return res.status(403).json({ error: "Access denied" });
      }

      const { userId } = req.params;
      const { tierId, reason } = req.body;
      const merchantId = req.user.id;
      
      if (!tierId) {
        return res.status(400).json({ error: "Tier ID required" });
      }

      // Update member's tier
      const result = await storage.updateMemberTier(merchantId, parseInt(userId), tierId, reason || "Manual tier adjustment by merchant");
      
      res.json({ success: true, result });
    } catch (error) {
      console.error("Error updating member tier:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Loyalty Rewards endpoints
  app.post("/api/loyalty/rewards", authenticateToken, async (req, res) => {
    try {
      if (req.user?.role !== "merchant") {
        return res.status(403).json({ error: "Access denied" });
      }

      const { name, costPoints, costStamps, terms, active } = req.body;
      const merchantId = req.user.id;

      if (!name) {
        return res.status(400).json({ error: "Reward name is required" });
      }

      // Get merchant's loyalty program
      const loyaltyProgram = await storage.getLoyaltyProgram(merchantId);
      if (!loyaltyProgram) {
        return res.status(404).json({ error: "Loyalty programme not found" });
      }

      // Create reward
      const reward = await storage.createLoyaltyReward({
        programId: loyaltyProgram.id,
        name,
        costPoints: costPoints || null,
        costStamps: costStamps || null,
        terms: terms || null,
        active: active !== false, // Default to true
      });

      res.json({ success: true, reward });
    } catch (error) {
      console.error("Error creating loyalty reward:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Apple Wallet Pass endpoints
  // Public Apple Wallet pass endpoint (no auth required for QR code access)
  app.get("/api/wallet/pass", async (req, res) => {
    try {
      if (!process.env.PASS_TYPE_IDENTIFIER || !process.env.TEAM_IDENTIFIER) {
        // Serve a simple HTML error page directly
        return res.send(`
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Apple Wallet Configuration</title>
</head>
<body style="margin:0;font-family:system-ui,-apple-system,sans-serif;background:#f9fafb;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:1rem">
  <div style="background:white;border-radius:1.5rem;padding:2rem;box-shadow:0 20px 25px -5px rgba(0,0,0,0.1);max-width:28rem;width:100%">
    <div style="display:flex;align-items:center;gap:0.75rem;margin-bottom:1rem">
      <div style="width:2rem;height:2rem;background:#fef2f2;border-radius:50%;display:flex;align-items:center;justify-content:center">
        <span style="color:#dc2626;font-size:1.125rem">⚠</span>
      </div>
      <h1 style="color:#7f1d1d;font-weight:600;font-size:1.125rem;margin:0">Apple Wallet Configuration</h1>
    </div>
    <p style="color:#b91c1c;margin:1rem 0;line-height:1.5">
      Apple Wallet integration is not yet configured on this server. The digital membership card feature will be available once the administrator sets up the required certificates.
    </p>
    <p style="color:#dc2626;font-size:0.875rem;margin:1rem 0 0 0">
      Please contact support for assistance or check back later.
    </p>
    <div style="margin-top:1.5rem">
      <a href="/" style="display:inline-block;background:#3b82f6;color:white;padding:0.5rem 1rem;border-radius:0.5rem;text-decoration:none;font-size:0.875rem;font-weight:500">
        Return to Home
      </a>
    </div>
  </div>
</body>
</html>
        `);
      }

      // For now, redirect to the authenticated endpoint
      // In production, this would generate a pass based on QR code parameters
      res.redirect('/wallet/resicard.pkpass');
    } catch (error) {
      console.error('Pass generation error:', error);
      // Serve error page directly instead of redirect
      res.send(`
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Apple Wallet Error</title>
</head>
<body style="margin:0;font-family:system-ui,-apple-system,sans-serif;background:#f9fafb;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:1rem">
  <div style="background:white;border-radius:1.5rem;padding:2rem;box-shadow:0 20px 25px -5px rgba(0,0,0,0.1);max-width:28rem;width:100%">
    <div style="display:flex;align-items:center;gap:0.75rem;margin-bottom:1rem">
      <div style="width:2rem;height:2rem;background:#fef2f2;border-radius:50%;display:flex;align-items:center;justify-content:center">
        <span style="color:#dc2626;font-size:1.125rem">⚠</span>
      </div>
      <h1 style="color:#7f1d1d;font-weight:600;font-size:1.125rem;margin:0">Apple Wallet Error</h1>
    </div>
    <p style="color:#b91c1c;margin:1rem 0;line-height:1.5">
      Failed to generate Apple Wallet pass. There was a technical issue with the pass generation service.
    </p>
    <p style="color:#dc2626;font-size:0.875rem;margin:1rem 0 0 0">
      Please try again later or contact support for assistance.
    </p>
    <div style="margin-top:1.5rem">
      <a href="/" style="display:inline-block;background:#3b82f6;color:white;padding:0.5rem 1rem;border-radius:0.5rem;text-decoration:none;font-size:0.875rem;font-weight:500">
        Return to Home
      </a>
    </div>
  </div>
</body>
</html>
      `);
    }
  });

  app.get("/wallet/resicard.pkpass", authenticateToken, async (req, res) => {
    if (!req.user) {
      return res.status(401).json({ error: "Authentication required" });
    }

    if (!passKitService.isConfigured()) {
      return res.status(503).json({ 
        error: "Apple Wallet pass service not configured. Please set PASS_TYPE_IDENTIFIER and TEAM_IDENTIFIER environment variables." 
      });
    }

    try {
      // Fetch additional user/merchant data for pass
      const userData = {
        id: req.user.id,
        username: req.user.username,
        email: req.user.email,
        loyaltyPoints: req.user.loyaltyPoints || 0,
        loyaltyTier: req.user.loyaltyTier || 'Standard',
        memberSince: req.user.createdAt ? new Date(req.user.createdAt).toLocaleDateString('en-GB') : new Date().toLocaleDateString('en-GB'),
        merchantName: 'Resicard St Andrews', // Default - could be merchant-specific
        offerTitle: '20% Off First Order',
        category: 'Food & Drink',
        expiryDate: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toLocaleDateString('en-GB'), // 90 days from now
        bookingUrl: 'https://resicard.co.uk/booking',
        contactInfo: 'Email: support@resicard.co.uk\nPhone: +44 1334 123456\nWebsite: resicard.co.uk',
        logoUrl: undefined // Could be fetched from merchant data
      };

      const passBuffer = await passKitService.generatePass(userData);
      
      res.setHeader('Content-Type', 'application/vnd.apple.pkpass');
      res.setHeader('Content-Disposition', 'attachment; filename="resicard.pkpass"');
      res.send(passBuffer);
    } catch (error) {
      console.error('Failed to generate Apple Wallet pass:', error);
      res.status(500).json({ error: "Failed to generate pass" });
    }
  });

  // Apple Wallet pass update endpoints (for future use)
  app.post("/api/wallet/v1/devices/:deviceLibraryIdentifier/registrations/:passTypeIdentifier/:serialNumber", (req, res) => {
    // Register device for pass updates
    console.log('Device registration for pass updates:', {
      deviceId: req.params.deviceLibraryIdentifier,
      passType: req.params.passTypeIdentifier,
      serialNumber: req.params.serialNumber,
      authToken: req.headers.authorization
    });
    res.status(201).send();
  });

  app.delete("/api/wallet/v1/devices/:deviceLibraryIdentifier/registrations/:passTypeIdentifier/:serialNumber", (req, res) => {
    // Unregister device for pass updates
    console.log('Device unregistration for pass updates:', {
      deviceId: req.params.deviceLibraryIdentifier,
      passType: req.params.passTypeIdentifier,
      serialNumber: req.params.serialNumber
    });
    res.status(200).send();
  });

  app.get("/api/wallet/v1/devices/:deviceLibraryIdentifier/registrations/:passTypeIdentifier", (req, res) => {
    // Get list of updatable passes for device
    const lastUpdated = req.query.passesUpdatedSince;
    console.log('Check for pass updates:', {
      deviceId: req.params.deviceLibraryIdentifier,
      passType: req.params.passTypeIdentifier,
      lastUpdated
    });
    
    // Return empty list for now - implement when push updates are needed
    res.json({
      lastUpdated: new Date().toISOString(),
      serialNumbers: []
    });
  });

  app.get("/api/wallet/v1/passes/:passTypeIdentifier/:serialNumber", (req, res) => {
    // Get updated pass
    console.log('Request for updated pass:', {
      passType: req.params.passTypeIdentifier,
      serialNumber: req.params.serialNumber,
      authToken: req.headers.authorization
    });
    
    // For now, return 304 Not Modified
    res.status(304).send();
  });

  app.post("/api/wallet/v1/log", (req, res) => {
    // Log messages from Wallet app
    console.log('Wallet app log:', req.body);
    res.status(200).send();
  });

  // Tier pricing routes for merchants
  app.get("/api/merchant/tier-pricing", authenticateToken, requireRole('merchant'), async (req, res) => {
    try {
      const merchant = await storage.getMerchantByUserId(req.user.id);
      if (!merchant) {
        return res.status(404).json({ message: "Merchant not found" });
      }

      // Get tier pricing for this merchant
      const tierPricing = await db.select().from(merchantTierPricing).where(eq(merchantTierPricing.merchantId, merchant.id));
      res.json(tierPricing);
    } catch (error: any) {
      console.error('Error fetching tier pricing:', error);
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/merchant/tier-pricing", authenticateToken, requireRole('merchant'), async (req, res) => {
    try {
      const merchant = await storage.getMerchantByUserId(req.user.id);
      if (!merchant) {
        return res.status(404).json({ message: "Merchant not found" });
      }

      const { tierPricingData } = req.body;
      
      // Delete existing pricing and insert new ones
      await db.delete(merchantTierPricing).where(eq(merchantTierPricing.merchantId, merchant.id));
      
      if (tierPricingData && tierPricingData.length > 0) {
        await db.insert(merchantTierPricing).values(
          tierPricingData.map((pricing: any) => ({
            merchantId: merchant.id,
            tierId: pricing.tierId,
            isAvailableForPurchase: pricing.isAvailableForPurchase,
            annualPrice: pricing.annualPrice,
            description: pricing.description,
            currency: pricing.currency || 'GBP',
          }))
        );
      }

      res.json({ message: "Tier pricing updated successfully" });
    } catch (error: any) {
      console.error('Error updating tier pricing:', error);
      res.status(500).json({ message: error.message });
    }
  });

  // User tier purchase routes
  app.get("/api/tiers/available/:merchantId", async (req, res) => {
    try {
      const { merchantId } = req.params;
      
      // Get available tier pricing for this merchant
      const availableTiers = await db
        .select({
          id: loyaltyTiers.id,
          name: loyaltyTiers.name,
          color: loyaltyTiers.color,
          thresholdPoints: loyaltyTiers.thresholdPoints,
          discountPercent: loyaltyTiers.discountPercent,
          pointsMultiplier: loyaltyTiers.pointsMultiplier,
          annualPrice: merchantTierPricing.annualPrice,
          description: merchantTierPricing.description,
          currency: merchantTierPricing.currency,
        })
        .from(merchantTierPricing)
        .innerJoin(loyaltyTiers, eq(merchantTierPricing.tierId, loyaltyTiers.id))
        .where(
          and(
            eq(merchantTierPricing.merchantId, merchantId),
            eq(merchantTierPricing.isAvailableForPurchase, true)
          )
        )
        .orderBy(loyaltyTiers.sortOrder);

      res.json(availableTiers);
    } catch (error: any) {
      console.error('Error fetching available tiers:', error);
      res.status(500).json({ message: error.message });
    }
  });

  // Get all merchants with their logos
  app.get("/api/merchants", async (req, res) => {
    try {
      // Get all merchants from database
      const merchantsList = await db.select().from(merchants);
      
      // For each merchant, also try to get the user's profilePhoto as logo
      const merchantsWithLogos = await Promise.all(
        merchantsList.map(async (merchant) => {
          let logoUrl = merchant.logoUrl;
          
          // If no logoUrl in merchant record, try to find user with matching email to get profilePhoto
          if (!logoUrl && merchant.email) {
            const [user] = await db.select({ profilePhoto: users.profilePhoto })
              .from(users)
              .where(eq(users.email, merchant.email));
            
            if (user?.profilePhoto) {
              logoUrl = user.profilePhoto;
            }
          }
          
          return {
            ...merchant,
            logoUrl,
            profilePhoto: logoUrl, // Also provide as profilePhoto for compatibility
          };
        })
      );
      
      res.json(merchantsWithLogos);
    } catch (error: any) {
      console.error('Error fetching merchants:', error);
      res.status(500).json({ message: "Failed to fetch merchants" });
    }
  });

  // Initialize loyalty tiers for Seaton House program (if missing)
  app.post("/api/loyalty/initialize-tiers", async (req, res) => {
    try {
      const programId = 3; // Seaton House program ID
      
      // Check if tiers already exist
      const existingTiers = await db.select().from(loyaltyTiers).where(eq(loyaltyTiers.programId, programId));
      
      if (existingTiers.length === 0) {
        // Create Bronze, Silver, Gold tiers
        const tierData = [
          {
            programId,
            name: 'Bronze',
            thresholdPoints: 0,
            discountPercent: 5,
            pointsMultiplier: '1.00',
            color: '#CD7F32',
            sortOrder: 1
          },
          {
            programId,
            name: 'Silver', 
            thresholdPoints: 100,
            discountPercent: 10,
            pointsMultiplier: '1.50',
            color: '#C0C0C0',
            sortOrder: 2
          },
          {
            programId,
            name: 'Gold',
            thresholdPoints: 250,
            discountPercent: 15,
            pointsMultiplier: '2.00',
            color: '#FFD700',
            sortOrder: 3
          }
        ];
        
        await db.insert(loyaltyTiers).values(tierData);
        
        // Update all existing user balances to correct tiers
        const userBalances = await db.select().from(loyaltyBalances).where(eq(loyaltyBalances.merchantId, 32));
        
        for (const balance of userBalances) {
          const points = Number(balance.balance);
          let newTier = 'Bronze';
          
          if (points >= 250) newTier = 'Gold';
          else if (points >= 100) newTier = 'Silver';
          
          await db.update(loyaltyBalances)
            .set({ tier: newTier })
            .where(and(eq(loyaltyBalances.merchantId, 32), eq(loyaltyBalances.userId, balance.userId)));
        }
        
        res.json({ message: "Tiers initialized successfully", tiers: tierData });
      } else {
        res.json({ message: "Tiers already exist", tiers: existingTiers });
      }
    } catch (error: any) {
      console.error('Error initializing tiers:', error);
      res.status(500).json({ message: "Failed to initialize tiers" });
    }
  });

  // Billing stats endpoint
  app.get("/api/billing/stats", authenticateToken, requireRole('merchant'), async (req, res) => {
    try {
      const merchantId = req.user?.id;
      if (!merchantId) {
        return res.status(401).json({ error: "User not authenticated" });
      }

      // Get current month redemptions for this merchant
      const now = new Date();
      const startOfCurrentMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      const endOfCurrentMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0);

      // Get merchant's UUID for offers table lookup
      const merchant = await storage.getMerchantByUserId(merchantId);
      const merchantUuid = merchant?.id;

      // Get all redemptions for this month and filter by merchant
      const redemptionResults = await db.execute(sql`
        SELECT 
          r.id,
          r.deal_id,
          r.user_id,
          r.redeemed_at,
          r.value,
          d.title as legacy_title,
          d.merchant_id as legacy_merchant_id
        FROM redemptions r
        LEFT JOIN deals d ON r.deal_id = d.id
        WHERE r.redeemed_at >= ${startOfCurrentMonth.toISOString()}
        AND r.redeemed_at <= ${endOfCurrentMonth.toISOString()}
        ORDER BY r.redeemed_at DESC
      `);

      // Filter to include only this merchant's redemptions and calculate fees
      let merchantRedemptions = [];
      
      for (const redemption of redemptionResults.rows) {
        let belongsToMerchant = false;
        let feeAmount = 0.50; // Default flat fee
        let feeModel = 'flat';
        let feePercent = null;
        
        // Check if it's a legacy deal redemption
        if (redemption.legacy_merchant_id === merchantId) {
          belongsToMerchant = true;
        } else {
          // Check if it's a UUID offer redemption by looking up the hashed deal_id
          const offers = await storage.getOffersByMerchant(merchantUuid);
          for (const offer of offers) {
            // Calculate the same hash we used when creating the redemption
            const offerHash = Math.abs(offer.id.split('-')[0].split('').reduce((a, b) => {
              a = ((a << 5) - a) + b.charCodeAt(0);
              return a & a;
            }, 0)) % 1000000;
            
            if (offerHash === parseInt(redemption.deal_id)) {
              belongsToMerchant = true;
              
              // Calculate fee based on offer's fee model
              if (offer.feeModel === 'percent_discount' && offer.customFee) {
                // Calculate the actual discount amount based on offer type
                let discountAmount = 0;
                if (offer.type === 'bogo' || offer.type === 'free_item_with_purchase') {
                  // For BOGO offers, use the discount value (what they saved)
                  discountAmount = offer.discountValue ? parseFloat(offer.discountValue) : 15; // Default BOGO discount
                } else if (offer.type === 'fixed_price_bundle') {
                  // For fixed price bundles: savings = original - fixed price  
                  discountAmount = offer.originalValue && offer.fixedPrice ? 
                    parseFloat(offer.originalValue) - parseFloat(offer.fixedPrice) : 200; // Default fixed bundle discount
                } else if (offer.discountType === 'percentage') {
                  // For percentage discounts, the stored value should be the discount amount
                  discountAmount = parseFloat(redemption.value);
                } else {
                  // For other types, use discount value or stored value
                  discountAmount = offer.discountValue ? parseFloat(offer.discountValue) : parseFloat(redemption.value);
                }
                
                // Fee is percentage of the actual discount amount
                feeAmount = (discountAmount * parseFloat(offer.customFee)) / 100;
                feeModel = 'percent_discount';
                feePercent = offer.customFee;
                
              }
              break;
            }
          }
        }
        
        if (belongsToMerchant) {
          // Find the offer title if it's a UUID offer
          let offerTitle = 'Legacy Offer';
          if (!redemption.legacy_merchant_id) {
            // Try to find matching offer by checking hash again
            const offers = await storage.getOffersByMerchant(merchantUuid);
            for (const offer of offers) {
              const offerHash = Math.abs(offer.id.split('-')[0].split('').reduce((a, b) => {
                a = ((a << 5) - a) + b.charCodeAt(0);
                return a & a;
              }, 0)) % 1000000;
              
              if (offerHash === parseInt(redemption.deal_id)) {
                offerTitle = offer.title;
                break;
              }
            }
          }

          merchantRedemptions.push({
            ...redemption,
            feeAmount,
            feeModel,
            feePercent,
            offerTitle
          });
        }
      }

      // Group redemptions by offer to create detailed breakdown
      const offerGroups = new Map();
      
      for (const redemption of merchantRedemptions) {
        const key = `${redemption.offerTitle || 'Legacy Offer'}-${redemption.feeModel}-${redemption.feePercent}`;
        
        if (!offerGroups.has(key)) {
          offerGroups.set(key, {
            offerTitle: redemption.offerTitle || 'Legacy Offer',
            feeModel: redemption.feeModel,
            feePercent: redemption.feePercent,
            count: 0,
            totalFeeAmount: 0,
            individualFee: redemption.feeAmount
          });
        }
        
        const group = offerGroups.get(key);
        group.count += 1;
        group.totalFeeAmount += redemption.feeAmount;
      }

      const totalRedemptions = merchantRedemptions.length;
      const totalFees = merchantRedemptions.reduce((sum, r) => sum + r.feeAmount, 0);
      const averageFee = totalRedemptions > 0 ? totalFees / totalRedemptions : 0;

      // Create detailed breakdown for display
      const detailedBreakdown = Array.from(offerGroups.values()).map(group => ({
        description: `${group.offerTitle} - Processing Fee`,
        quantity: group.count,
        rate: Math.round(group.individualFee * 100) / 100,
        amount: Math.round(group.totalFeeAmount * 100) / 100,
        feeModel: group.feeModel,
        feePercent: group.feePercent
      }));

      // Add monthly subscription fee to breakdown
      const monthlySubscriptionFee = 29.99;
      detailedBreakdown.push({
        description: "Monthly Platform Subscription",
        quantity: 1,
        rate: Math.round(monthlySubscriptionFee * 100) / 100,
        amount: Math.round(monthlySubscriptionFee * 100) / 100,
        feeModel: 'subscription',
        feePercent: null
      });

      // Calculate VAT (20%) on total fees including subscription
      const totalNetFees = totalFees + monthlySubscriptionFee;
      const netFees = Math.round(totalNetFees * 100) / 100;
      const vatAmount = Math.round(netFees * 0.20 * 100) / 100;
      const grossFees = Math.round((netFees + vatAmount) * 100) / 100;

      res.json({
        period: now.toLocaleDateString('en-GB', { month: 'long', year: 'numeric' }),
        redemptions: totalRedemptions,
        netFees: netFees,
        vatAmount: vatAmount,
        totalFees: grossFees,
        averageFee: Math.round(averageFee * 100) / 100,
        detailedBreakdown,
        status: 'draft'
      });
    } catch (error) {
      console.error("Error fetching billing stats:", error);
      res.status(500).json({ error: "Failed to fetch billing stats" });
    }
  });

  // Subscription settings endpoints
  app.get("/api/subscription/settings", authenticateToken, requireRole('merchant'), async (req, res) => {
    try {
      const merchantId = req.user?.id;
      if (!merchantId) {
        return res.status(401).json({ error: "User not authenticated" });
      }

      // Calculate next billing date (15 days after month end)
      const now = new Date();
      const nextMonth = new Date(now.getFullYear(), now.getMonth() + 1, 1);
      const endOfNextMonth = new Date(nextMonth.getFullYear(), nextMonth.getMonth() + 1, 0);
      const nextBillingDate = new Date(endOfNextMonth);
      nextBillingDate.setDate(endOfNextMonth.getDate() + 15);

      // Mock joining date (in real implementation, this would come from database)
      const joiningDate = new Date('2024-08-15'); // Example joining date

      // For now, return default settings - in the future this could be stored in the database
      const defaultSettings = {
        monthlyFee: 29.99,
        processingFeePercent: 10.0,
        status: 'trial',
        nextBillingDate: nextBillingDate.toISOString(),
        trialEndsAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
        joiningDate: joiningDate.toISOString()
      };

      res.json(defaultSettings);
    } catch (error) {
      console.error("Error fetching subscription settings:", error);
      res.status(500).json({ error: "Failed to fetch subscription settings" });
    }
  });

  app.put("/api/subscription/settings", authenticateToken, requireRole('merchant'), async (req, res) => {
    try {
      const merchantId = req.user?.id;
      if (!merchantId) {
        return res.status(401).json({ error: "User not authenticated" });
      }

      const { processingFeePercent } = req.body;

      // Validate the processing fee percentage
      if (processingFeePercent < 0 || processingFeePercent > 100) {
        return res.status(400).json({ error: "Processing fee percentage must be between 0 and 100" });
      }

      // For now, just return success - in the future this would update the database
      console.log(`Merchant ${merchantId} updated processing fee to ${processingFeePercent}%`);

      res.json({ 
        success: true, 
        message: "Subscription settings updated successfully",
        processingFeePercent: processingFeePercent
      });
    } catch (error) {
      console.error("Error updating subscription settings:", error);
      res.status(500).json({ error: "Failed to update subscription settings" });
    }
  });

  // Serve set menu PDFs
  app.get("/api/offers/:id/menu-pdf", async (req, res) => {
    try {
      const offerId = req.params.id;
      const offer = await storage.getOffer(offerId);
      
      if (!offer) {
        return res.status(404).json({ error: "Offer not found" });
      }
      
      if (offer.type !== "set_menu" || !offer.menuPdf) {
        return res.status(404).json({ error: "Menu PDF not found" });
      }
      
      // Extract the base64 data from the data URL
      const base64Data = offer.menuPdf.replace(/^data:application\/pdf;base64,/, '');
      const pdfBuffer = Buffer.from(base64Data, 'base64');
      
      res.set({
        'Content-Type': 'application/pdf',
        'Content-Disposition': `inline; filename="${offer.title}_menu.pdf"`,
        'Content-Length': pdfBuffer.length
      });
      
      res.send(pdfBuffer);
      
    } catch (error) {
      console.error('Error serving menu PDF:', error);
      res.status(500).json({ error: "Failed to serve menu PDF" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
